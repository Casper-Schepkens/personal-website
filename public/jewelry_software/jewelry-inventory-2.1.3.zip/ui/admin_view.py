from nicegui import ui

from config.settings import APP_VERSION, HOSTING_DIR, LICENSE_JSON_PATH
from core.dev_mode_service import company_app_url, clear_local_sign_in, start_company_app
from core.license_service import (
    _fetch_license_json,
    _latest_version,
    list_shop_summaries,
    set_shop_flags,
)
from core.release_service import (
    compare_versions,
    format_build_summary,
    prepare_release_for_hosting,
    read_app_version,
    validate_version,
)


def _header(title: str, back_path: str | None = None) -> None:
    with ui.row().classes("w-full items-center justify-between mb-4"):
        ui.label(title).classes("text-2xl font-bold")
        if back_path:
            ui.link("Back", back_path).classes("text-sm text-gray-500")

    ui.label(f"Software admin · app v{APP_VERSION}").classes("text-sm text-gray-500 mb-6")


def show_admin_dashboard() -> None:
    _header("Admin dashboard")

    ui.label("Company app").classes("text-lg font-semibold mb-2")
    with ui.row().classes("gap-3 mb-2 flex-wrap"):
        ui.button(
            "Open company app (dev)",
            on_click=_open_company_app_in_dev_mode,
        ).props("no-caps color=primary")
        ui.button(
            "Sign out company app",
            on_click=_sign_out_company_app,
        ).props("no-caps outline color=negative")
        ui.button(
            "Create / publish update",
            on_click=lambda: ui.navigate.to("/create-update"),
        ).props("no-caps color=primary outline")

    ui.label(
        f"Dev mode opens {company_app_url()} with local_data/ and skips license login."
    ).classes("text-sm text-gray-600 mb-8")

    ui.label("Kill switch & updates").classes("text-lg font-semibold mb-2")
    ui.label(
        "These flags live in ops/license.json. After changing them, copy "
        "hosting/license.json (or ops/license.json) up to casperschepkens.com so "
        "Raj’s app/updater sees the change on next start."
    ).classes("text-sm text-gray-600 mb-4")

    try:
        license_data = _fetch_license_json()
        latest = _latest_version(license_data) or "-"
        ui.label(f"latest_version in license.json: v{latest}").classes(
            "text-sm text-gray-600 mb-4"
        )
        accounts = list_shop_summaries()
    except Exception as exc:
        ui.label(f"Could not load accounts: {exc}").classes("text-red-600")
        return

    if not accounts:
        ui.label(f"No shops found in {LICENSE_JSON_PATH}").classes("text-amber-700")
        return

    for account in accounts:
        with ui.card().classes("w-full max-w-3xl mb-3 p-4"):
            ui.label(account.display_name).classes("text-base font-semibold")
            ui.label(
                f"{account.shop_id} · {account.account_type} · user {account.username}"
            ).classes("text-sm text-gray-500 mb-3")

            with ui.row().classes("gap-8 flex-wrap items-center"):
                enabled_toggle = ui.switch(
                    "App enabled (kill switch off when disabled)",
                    value=account.app_enabled,
                )

                updates_toggle = ui.switch(
                    "Updates enabled",
                    value=account.updates_enabled,
                )

            status = ui.label("").classes("text-sm text-gray-600 mt-2")

            def _save(
                shop_id=account.shop_id,
                enabled_sw=enabled_toggle,
                updates_sw=updates_toggle,
                status_label=status,
            ) -> None:
                try:
                    set_shop_flags(
                        shop_id,
                        app_enabled=bool(enabled_sw.value),
                        updates_enabled=bool(updates_sw.value),
                    )
                    from core.release_service import sync_license_to_hosting

                    sync_license_to_hosting()
                    status_label.text = (
                        "Saved to ops/license.json and hosting/license.json — "
                        "upload hosting/license.json to the website to apply remotely."
                    )
                    ui.notify("License flags saved", type="positive")
                except Exception as exc:
                    status_label.text = str(exc)
                    ui.notify(str(exc), type="negative")

            enabled_toggle.on("update:model-value", lambda _: _save())
            updates_toggle.on("update:model-value", lambda _: _save())


def show_create_update_page() -> None:
    _header("Create / publish update", back_path="/")

    try:
        current_version = read_app_version()
    except ValueError as exc:
        ui.label(str(exc)).classes("text-red-600")
        return

    ui.label("How updates work").classes("text-lg font-semibold mb-2")
    ui.markdown(
        """
1. **App version** lives in `app/config/settings.py` as `APP_VERSION` (e.g. `2.1.4`).
2. **Build** writes the zip `jewelry-inventory-{version}.zip` into `hosting/releases/`.
3. **license.json** field `latest_version` is set to that same version and copied to `hosting/license.json`.
4. You (or the website agent) upload both files to:
   - `https://casperschepkens.com/jewelry_software/license.json`
   - `https://casperschepkens.com/jewelry_software/jewelry-inventory-{version}.zip`
5. On Raj’s PC, `updater.py` downloads the license. If `latest_version` ≠ installed
   `APP_VERSION` and **Updates** is on for his shop, it replaces `project/` with the zip.
   If **App enabled** is off, the updater hard-stops with “License not valid. Contact Casper.”
        """
    ).classes("text-sm text-gray-700 mb-6")

    ui.label("Current version").classes("text-sm text-gray-500")
    ui.label(f"v{current_version}").classes("text-3xl font-bold mb-6")

    new_version_input = ui.input("New version").props("outlined dense").classes("max-w-xs")
    new_version_input.value = current_version
    comparison = ui.label("").classes("text-sm text-gray-600 min-h-[1.25rem] mb-2")
    result = ui.label("").classes("text-sm whitespace-pre-wrap text-gray-700 mb-4")
    busy = {"value": False}

    def refresh_comparison() -> None:
        value = (new_version_input.value or "").strip()
        if not value:
            comparison.text = ""
            return
        try:
            validate_version(value)
        except ValueError as exc:
            comparison.text = str(exc)
            comparison.classes(
                remove="text-green-600 text-amber-600 text-red-600", add="text-red-600"
            )
            return

        order = compare_versions(value, current_version)
        if order > 0:
            comparison.text = f"v{value} is newer than the current v{current_version}."
            comparison.classes(
                remove="text-red-600 text-amber-600 text-green-600", add="text-green-600"
            )
        elif order < 0:
            comparison.text = f"v{value} is older than the current v{current_version}."
            comparison.classes(
                remove="text-red-600 text-green-600 text-amber-600", add="text-amber-600"
            )
        else:
            comparison.text = "Same as the current version."
            comparison.classes(
                remove="text-red-600 text-green-600 text-amber-600", add="text-amber-600"
            )

    new_version_input.on("update:model-value", lambda _: refresh_comparison())
    refresh_comparison()

    def create_update() -> None:
        if busy["value"]:
            return
        busy["value"] = True
        result.text = ""
        try:
            new_version = validate_version(new_version_input.value or "")
            prepared = prepare_release_for_hosting(new_version)
            result.text = format_build_summary(
                prepared["zip_path"], prepared["version"], prepared["file_count"]
            )
            result.text += (
                f"\n\nStaged for upload in {HOSTING_DIR}:\n"
                f"- {prepared['zip_path']}\n"
                f"- {prepared['hosting_license']}\n"
                "\nWebsite is Next.js — upload those two files to the paths above "
                "(another Cursor agent can wire the site routes)."
            )
            ui.notify(f"Release ready: v{prepared['version']}", type="positive")
        except Exception as exc:
            result.text = str(exc)
            ui.notify(str(exc), type="negative")
        finally:
            busy["value"] = False

    ui.button("Build zip + stage license", on_click=create_update).props(
        "no-caps color=primary"
    )


def _sign_out_company_app() -> None:
    try:
        clear_local_sign_in()
    except Exception as exc:
        ui.notify(str(exc), type="negative")
        return
    ui.notify(
        "Company app signed out — session cleared and dev mode disabled.",
        type="positive",
    )


def _open_company_app_in_dev_mode() -> None:
    import webbrowser

    try:
        url, message = start_company_app()
    except Exception as exc:
        ui.notify(str(exc), type="negative")
        return

    webbrowser.open(url)
    notify_type = "warning" if "already running" in message.lower() else "positive"
    ui.notify(message, type=notify_type)


def register_admin_dashboard() -> None:
    @ui.page("/")
    def admin_home() -> None:
        show_admin_dashboard()

    @ui.page("/create-update")
    def create_update_page() -> None:
        show_create_update_page()
