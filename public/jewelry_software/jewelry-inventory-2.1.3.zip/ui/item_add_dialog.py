from collections.abc import Callable

from nicegui import ui
from config.item_options import (
    CERTIFICATE_OPTIONS,
    CONSIGNMENT_OPTIONS,
    ITEM_TYPES,
    METALS,
    STONES,
    STOCK_OPTIONS,
)
from core.phone_upload_service import process_phone_uploads
from core.image_service import resolve_photo_source, save_image_for_item
from core.inventory_service import create_item, set_item_photo_path
from ui.photo_display import PHOTO_PROPS, PHOTO_STYLE, PLACEHOLDER_SRC, bind_photo, open_image_zoom
from ui.photo_helpers import pick_photo_from_folder

SELECT_PROPS = "dense outlined clearable"


def _require(value, label: str) -> bool:
    if value is None or value == "":
        ui.notify(f"Please select or enter: {label}", type="negative")
        return False
    return True


def _num(value) -> float:
    if value is None or value == "":
        return 0.0
    return float(value)


def open_item_add_dialog(on_saved: Callable[[], None] | None = None) -> None:
    converted, phone_errors = process_phone_uploads()
    if converted:
        ui.notify(
            f"{converted} phone photo(s) converted and moved to images_to_add",
            type="positive",
        )
    for message in phone_errors[:5]:
        ui.notify(f"Phone photo failed: {message}", type="warning")
    if len(phone_errors) > 5:
        ui.notify(f"…and {len(phone_errors) - 5} more phone photo errors", type="warning")

    selected: dict = {"path": None}

    with ui.dialog() as dialog, ui.card().classes("p-6 w-full max-w-lg"):
        ui.label("Add new item").classes("text-xl font-bold mb-4")

        preview = ui.image(PLACEHOLDER_SRC).classes(
            "w-full rounded bg-gray-50 mb-2 cursor-zoom-in"
        ).style(PHOTO_STYLE).props(PHOTO_PROPS)

        def update_preview() -> None:
            path = selected["path"]
            if not path:
                preview.set_source(PLACEHOLDER_SRC)
                return
            bind_photo(preview, resolve_photo_source(path))

        def pick_photo() -> None:
            path = pick_photo_from_folder()
            if not path:
                return
            selected["path"] = path
            update_preview()

        def zoom_preview() -> None:
            if selected["path"]:
                open_image_zoom(resolve_photo_source(selected["path"]))

        preview.on("click", zoom_preview)

        ui.button("Choose photo", on_click=pick_photo).classes("w-full mb-1").props(
            "no-caps outline"
        )
        ui.label(
            "Opens file explorer in assets/images_to_add"
        ).classes("text-xs text-gray-500 mb-4 text-center w-full")
        ui.label("Click selected photo to zoom").classes(
            "text-xs text-gray-500 mb-4 text-center w-full"
        )

        item_type_select = ui.select(
            ITEM_TYPES, label="Item type", value=None
        ).classes("w-full").props(SELECT_PROPS)

        weight_input = ui.number(
            "Weight (g)", value=None, format="%.2f", min=0
        ).classes("w-full").props("dense outlined")

        stone_select = ui.select(
            STONES, label="Stone", value=None
        ).classes("w-full").props(SELECT_PROPS)

        carat_input = ui.number(
            "Carat", value=None, format="%.2f", min=0
        ).classes("w-full").props("dense outlined")

        sidestone_select = ui.select(
            STONES, label="Sidestone", value=None
        ).classes("w-full").props(SELECT_PROPS)

        sidestone_carat_input = ui.number(
            "Sidestone carat", value=None, format="%.2f", min=0
        ).classes("w-full").props("dense outlined")

        purchase_input = ui.number(
            "Purchase price", value=None, format="%.2f", min=0
        ).classes("w-full").props("dense outlined")

        sell_input = ui.number(
            "Sell price", value=None, format="%.2f", min=0
        ).classes("w-full").props("dense outlined")

        metal_select = ui.select(
            METALS, label="Metal", value=None
        ).classes("w-full").props(SELECT_PROPS)

        stock_select = ui.select(
            STOCK_OPTIONS, label="In stock", value=None
        ).classes("w-full").props(SELECT_PROPS)

        certificate_select = ui.select(
            CERTIFICATE_OPTIONS, label="Certificate", value=None
        ).classes("w-full").props(SELECT_PROPS)

        consignment_select = ui.select(
            CONSIGNMENT_OPTIONS, label="Consignment", value="no"
        ).classes("w-full").props(SELECT_PROPS)

        def confirm_add() -> None:
            if submit_state["busy"]:
                return
            if not _require(selected["path"], "Photo"):
                return
            if not _require(item_type_select.value, "Item type"):
                return
            if not _require(stone_select.value, "Stone"):
                return
            if not _require(sidestone_select.value, "Sidestone"):
                return
            if not _require(metal_select.value, "Metal"):
                return
            if not _require(stock_select.value, "In stock"):
                return
            if not _require(certificate_select.value, "Certificate"):
                return

            submit_state["busy"] = True
            confirm_btn.disable()

            try:
                item_id = create_item(
                    item_type=item_type_select.value,
                    weight=_num(weight_input.value),
                    stone=stone_select.value,
                    carat=_num(carat_input.value),
                    sidestone=sidestone_select.value,
                    sidestone_carat=_num(sidestone_carat_input.value),
                    purchase_price=_num(purchase_input.value),
                    sell_price=_num(sell_input.value),
                    metal=metal_select.value,
                    stock=stock_select.value,
                    certificate=certificate_select.value,
                    consignment=consignment_select.value or "no",
                )
                photo_path = save_image_for_item(item_id, selected["path"])
                set_item_photo_path(item_id, photo_path)
            except (TypeError, ValueError, OSError) as exc:
                submit_state["busy"] = False
                confirm_btn.enable()
                ui.notify(f"Could not add item: {exc}", type="negative")
                return

            dialog.close()
            ui.notify(f"Item #{item_id} added", type="positive")
            if on_saved:
                on_saved()

        submit_state = {"busy": False}
        confirm_btn = ui.button("Confirm add", on_click=confirm_add).classes(
            "w-full mt-6 bg-green-600 text-white"
        ).props("no-caps")

    dialog.open()
