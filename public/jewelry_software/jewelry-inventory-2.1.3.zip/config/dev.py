"""Load local development settings from local_data/dev_settings.py."""

from __future__ import annotations

import importlib.util
import os

from config.settings import ADMIN_DIR, DEV_SETTINGS_PATH
from core.session_service import ACCOUNT_TYPE_ADMIN, ACCOUNT_TYPE_COMPANY, AppSession

_dev_settings_module = None
_dev_settings_mtime: float | None = None


def is_dev_workspace() -> bool:
    """True when running from the developer repo (ops/ folder present)."""
    return os.path.isdir(ADMIN_DIR)


def clear_dev_settings_cache() -> None:
    global _dev_settings_module, _dev_settings_mtime
    _dev_settings_module = None
    _dev_settings_mtime = None


def _load_dev_settings_module():
    global _dev_settings_module, _dev_settings_mtime
    if not os.path.isfile(DEV_SETTINGS_PATH):
        _dev_settings_module = None
        _dev_settings_mtime = None
        return None

    mtime = os.path.getmtime(DEV_SETTINGS_PATH)
    if _dev_settings_module is not None and _dev_settings_mtime == mtime:
        return _dev_settings_module

    spec = importlib.util.spec_from_file_location("local_dev_settings", DEV_SETTINGS_PATH)
    if spec is None or spec.loader is None:
        return None

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _dev_settings_module = module
    _dev_settings_mtime = mtime
    return module


def is_dev_mode() -> bool:
    module = _load_dev_settings_module()
    if module is None:
        return False
    return bool(getattr(module, "DEV_MODE", False))


def _dev_settings():
    module = _load_dev_settings_module()
    if module is None:
        raise RuntimeError(
            f"Development mode requires {DEV_SETTINGS_PATH}. "
            "Copy dev_settings.example.py to dev_settings.py in your local_data folder."
        )
    return module


def dev_account_type() -> str:
    settings = _dev_settings()
    account_type = str(getattr(settings, "DEV_ACCOUNT_TYPE", ACCOUNT_TYPE_COMPANY)).strip().lower()
    if account_type == ACCOUNT_TYPE_ADMIN:
        return ACCOUNT_TYPE_ADMIN
    return ACCOUNT_TYPE_COMPANY


def dev_session() -> AppSession:
    settings = _dev_settings()
    account_type = dev_account_type()
    return AppSession(
        shop_id=str(getattr(settings, "DEV_SHOP_ID", "local-dev")),
        display_name=str(getattr(settings, "DEV_DISPLAY_NAME", "Local Development")),
        account_type=account_type,
    )


def ensure_dev_session() -> AppSession | None:
    if not is_dev_mode():
        return None
    from core.session_service import save_session

    session = dev_session()
    save_session(session)
    return session
