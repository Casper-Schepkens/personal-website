"""Install Python packages from requirements.txt (stdlib only — safe before app imports)."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def _project_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def _should_auto_install() -> bool:
    return True


def ensure_dependencies() -> None:
    if not _should_auto_install():
        return

    requirements = _project_dir() / "requirements.txt"
    if not requirements.is_file():
        return

    print("Checking Python packages ...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", str(requirements)],
        cwd=str(_project_dir()),
    )
    if result.returncode != 0:
        print(
            "Could not install required packages. "
            f"Run manually: python -m pip install -r {requirements}",
            file=sys.stderr,
        )
        sys.exit(result.returncode)
