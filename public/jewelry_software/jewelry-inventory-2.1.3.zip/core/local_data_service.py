"""Create and prepare the client local_data folder on first sign-in."""

from __future__ import annotations

from pathlib import Path

from config.dev import is_dev_mode
from config.settings import (
    CLIENT_README_PATH,
    CLIENT_README_TEXT,
    DB_PATH,
    BRANDING_DIR,
    IMAGES_TO_ADD_DIR,
    IMAGE_DIR,
    LOCAL_DATA_DIR,
    PHONE_UPLOAD_DIR,
    SESSION_PATH,
    THUMB_DIR,
)
from core.session_service import AppSession
from data.db import get_connection


def is_first_run() -> bool:
    """No saved session yet (typical first launch after extracting an update zip)."""
    if is_dev_mode():
        return False
    return not Path(SESSION_PATH).is_file()


def ensure_local_data_layout() -> None:
    """Folders and readme for local_data; safe to call on every startup."""
    for path in (
        LOCAL_DATA_DIR,
        IMAGE_DIR,
        THUMB_DIR,
        IMAGES_TO_ADD_DIR,
        PHONE_UPLOAD_DIR,
        BRANDING_DIR,
    ):
        Path(path).mkdir(parents=True, exist_ok=True)

    readme = Path(CLIENT_README_PATH)
    if not readme.is_file():
        readme.write_text(CLIENT_README_TEXT, encoding="utf-8")


def ensure_database() -> None:
    """Open the database so schema exists (empty db if this is a new shop)."""
    conn = get_connection()
    conn.close()


def complete_sign_in(session: AppSession) -> None:
    """After a successful license login, prepare local_data and save the session."""
    from core.session_service import save_session

    ensure_local_data_layout()
    ensure_database()
    save_session(session)


def local_data_summary() -> str:
    db_exists = Path(DB_PATH).is_file()
    return "existing database" if db_exists else "new empty database"
