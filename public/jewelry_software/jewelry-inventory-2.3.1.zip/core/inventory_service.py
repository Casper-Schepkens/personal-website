from data.inventory_repo import (
    CONSIGNMENT_FILTER_VALUES,
    FILTER_COLUMNS,
    delete_item,
    get_all_items_for_export,
    get_filtered_count,
    get_inventory_stats,
    get_item_by_id,
    get_items,
    get_sell_price_bounds,
    get_value_counts,
    insert_item,
    mark_item_sold,
    update_item,
    update_photo_path,
)
from core.image_service import delete_item_images

FILTER_LABELS = {
    "item_type": "Type",
    "metal": "Metal",
    "stone": "Stone",
    "sidestone": "Sidestone",
    "stock": "Stock",
    "consignment": "Consignment",
}

CONSIGNMENT_FILTER_DEFAULT = "all"
CONSIGNMENT_FILTER_LABELS = {
    "all": "All",
    "only": "Consignments only",
    "exclude": "Without consignments",
}


def _normalize_filters(**filters) -> dict:
    normalized = {}
    for column in FILTER_COLUMNS:
        value = filters.get(column, "All") or "All"
        if column == "consignment":
            cleaned = str(value).strip().lower()
            if cleaned not in CONSIGNMENT_FILTER_VALUES:
                cleaned = CONSIGNMENT_FILTER_DEFAULT
            normalized[column] = cleaned
        else:
            normalized[column] = value
    return normalized


def _parse_item_id(value) -> int | None:
    text = str(value or "").strip()
    if not text:
        return None
    if not text.isdigit():
        return -1
    return int(text)


def _query_kwargs(**filters) -> dict:
    normalized = _normalize_filters(**filters)
    return {
        **normalized,
        "item_id": _parse_item_id(filters.get("item_id")),
        "price_min": filters.get("price_min"),
        "price_max": filters.get("price_max"),
    }


def load_price_bounds() -> tuple[float, float]:
    minimum, maximum = get_sell_price_bounds()
    if maximum <= minimum:
        return 0.0, 10_000.0
    return minimum, maximum


def load_filter_options(**filters) -> dict[str, dict[str, str]]:
    """NiceGUI select options: value -> label."""
    query = _query_kwargs(**filters)
    options_by_column: dict[str, dict[str, str]] = {}

    for column in FILTER_COLUMNS:
        labeled: dict[str, str] = {}
        if column != "consignment":
            all_count = get_filtered_count(exclude=column, **query)
            labeled["All"] = f"All ({all_count})"

        for value, count in get_value_counts(column, **query):
            if column == "consignment":
                base = CONSIGNMENT_FILTER_LABELS.get(value, value)
                labeled[value] = f"{base} ({count})"
            else:
                labeled[value] = f"{value} ({count})"

        options_by_column[column] = labeled

    return options_by_column


def load_inventory_stats(**filters) -> dict:
    return get_inventory_stats(**_query_kwargs(**filters))


def load_inventory(**filters) -> list:
    return get_items(**_query_kwargs(**filters))


def load_item(item_id: int):
    return get_item_by_id(item_id)


def save_item(
    item_id: int,
    *,
    item_type: str,
    weight: float,
    stone: str,
    carat: float,
    sidestone: str,
    sidestone_carat: float,
    purchase_price: float,
    sell_price: float,
    metal: str,
    stock: str,
    certificate: str,
    consignment: str,
) -> None:
    update_item(
        item_id,
        item_type=item_type,
        weight=weight,
        stone=stone,
        carat=carat,
        sidestone=sidestone,
        sidestone_carat=sidestone_carat,
        purchase_price=purchase_price,
        sell_price=sell_price,
        metal=metal,
        stock=stock,
        certificate=certificate,
        consignment=consignment,
    )


def create_item(
    *,
    item_type: str,
    weight: float,
    stone: str,
    carat: float,
    sidestone: str,
    sidestone_carat: float,
    purchase_price: float,
    sell_price: float,
    metal: str,
    stock: str,
    certificate: str,
    consignment: str = "no",
    photo_path: str | None = None,
) -> int:
    return insert_item(
        item_type=item_type,
        weight=weight,
        stone=stone,
        carat=carat,
        sidestone=sidestone,
        sidestone_carat=sidestone_carat,
        purchase_price=purchase_price,
        sell_price=sell_price,
        metal=metal,
        stock=stock,
        certificate=certificate,
        consignment=consignment,
        photo_path=photo_path,
    )


def sell_item(item_id: int) -> None:
    mark_item_sold(item_id)


def set_item_photo_path(item_id: int, photo_path: str) -> None:
    update_photo_path(item_id, photo_path)


def remove_item(item_id: int) -> None:
    delete_item(item_id)
    delete_item_images(item_id)


def load_all_items_for_export() -> list:
    return get_all_items_for_export()
