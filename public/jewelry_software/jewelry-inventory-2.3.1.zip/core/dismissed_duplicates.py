"""Persist acknowledged (dismissed) duplicate groups."""

from __future__ import annotations

import json
import os
from pathlib import Path

from config.settings import LOCAL_DATA_DIR
from core.duplicate_service import DuplicateGroup

DISMISSED_PATH = Path(LOCAL_DATA_DIR) / "dismissed_duplicates.json"


def group_key(group: DuplicateGroup) -> str:
    ids = ",".join(str(item_id) for item_id in group.item_ids)
    return f"{group.reason}:{ids}"


def load_dismissed_keys() -> set[str]:
    if not DISMISSED_PATH.is_file():
        return set()
    try:
        raw = json.loads(DISMISSED_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return set()
    if not isinstance(raw, list):
        return set()
    return {str(item) for item in raw}


def save_dismissed_keys(keys: set[str]) -> None:
    os.makedirs(LOCAL_DATA_DIR, exist_ok=True)
    ordered = sorted(keys)
    DISMISSED_PATH.write_text(json.dumps(ordered, indent=2) + "\n", encoding="utf-8")


def dismiss_group(group: DuplicateGroup) -> None:
    keys = load_dismissed_keys()
    keys.add(group_key(group))
    save_dismissed_keys(keys)


def restore_group(group: DuplicateGroup) -> None:
    keys = load_dismissed_keys()
    keys.discard(group_key(group))
    save_dismissed_keys(keys)


def split_duplicate_groups(
    groups: list[DuplicateGroup],
) -> tuple[list[DuplicateGroup], list[DuplicateGroup]]:
    dismissed_keys = load_dismissed_keys()
    active: list[DuplicateGroup] = []
    dismissed: list[DuplicateGroup] = []
    for group in groups:
        if group_key(group) in dismissed_keys:
            dismissed.append(group)
        else:
            active.append(group)
    return active, dismissed


def active_duplicate_group_count(items=None) -> int:
    from core.duplicate_service import find_duplicate_groups

    active, _ = split_duplicate_groups(find_duplicate_groups(items))
    return len(active)
