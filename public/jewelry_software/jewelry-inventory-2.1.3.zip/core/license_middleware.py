from starlette.requests import Request
from starlette.responses import HTMLResponse, RedirectResponse, Response

from config.dev import ensure_dev_session, is_dev_mode, is_dev_workspace
from config.settings import LICENSE_BLOCK_MESSAGE
from core.dev_mode_service import DEV_SHOP_ID
from core.license_service import fetch_license_status
from core.session_service import clear_session, load_session

_PUBLIC_PREFIXES = ("/login", "/upload", "/_nicegui")


def _block_html(message: str | None) -> str:
    body = ""
    if message:
        escaped = (
            message.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "<br>")
        )
        body = f"    <p>{escaped}</p>\n"
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Application unavailable</title>
  <style>
    body {{ font-family: sans-serif; display: flex; min-height: 100vh; margin: 0;
           align-items: center; justify-content: center; background: #fafafa; }}
    .panel {{ max-width: 36rem; padding: 2rem; text-align: center; }}
    h1 {{ color: #dc2626; margin-bottom: 1rem; }}
    p {{ color: #374151; line-height: 1.6; }}
    a {{ color: #2563eb; }}
  </style>
</head>
<body>
  <div class="panel">
    <h1>Application unavailable</h1>
{body}    <p><a href="/login">Sign in with a different account</a></p>
  </div>
</body>
</html>"""


async def license_middleware(request: Request, call_next) -> Response:
    path = request.url.path
    if any(path.startswith(prefix) for prefix in _PUBLIC_PREFIXES):
        return await call_next(request)

    if is_dev_mode():
        ensure_dev_session()
        return await call_next(request)

    session = load_session()
    if session is None:
        return RedirectResponse("/login", status_code=302)

    if session.shop_id == DEV_SHOP_ID:
        clear_session()
        return RedirectResponse("/login", status_code=302)

    if session.is_admin and not is_dev_workspace():
        return HTMLResponse(
            _block_html(
                "Administrator accounts use the separate admin dashboard.\n\n"
                "Run: python ops/admin_main.py"
            ),
            status_code=403,
        )

    status = fetch_license_status(
        session.shop_id,
        display_name=session.display_name,
        account_type=session.account_type,
    )
    if not status.is_accessible:
        clear_session()
        return HTMLResponse(
            _block_html(status.block_message or LICENSE_BLOCK_MESSAGE),
            status_code=403,
        )

    return await call_next(request)
