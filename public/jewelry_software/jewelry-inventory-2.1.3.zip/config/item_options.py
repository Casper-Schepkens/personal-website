ITEM_TYPES = [
    "earring",
    "ring",
    "pendant",
    "bracelet",
    "necklace",
    "broche",
    "loose stone",
]

STONES = [
    "diamond",
    "sapphire",
    "ruby",
    "topaz",
    "aquamarine",
    "citrine",
    "peridot",
    "pearl",
    "emerald",
    "amethyst",
    "garnet",
    "tanzanite",
    "rose quartz",
    "lapis lazuli",
    "rhodolite",
    "opal",
    "other",
    "none",
]

METALS = ["white gold", "yellow gold", "rose gold", "platinum", "none"]

STOCK_OPTIONS = ["in stock", "reserved", "sold"]

CERTIFICATE_OPTIONS = ["yes", "no"]

CONSIGNMENT_OPTIONS = ["no", "yes"]
