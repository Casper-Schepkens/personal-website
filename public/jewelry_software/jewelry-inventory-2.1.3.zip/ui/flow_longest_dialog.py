from datetime import datetime

from nicegui import ui

from core.flow_service import load_longest_in_stock


def _format_euro(amount: float) -> str:
    return f"€ {int(round(amount)):,}"


def _format_item_date(value: str) -> str:
    try:
        return datetime.strptime(value[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        return value[:10]


def open_longest_in_stock_dialog(*, item_type: str = "All", limit: int = 25) -> None:
    items = load_longest_in_stock(item_type=item_type, limit=limit)

    with ui.dialog() as dialog, ui.card().classes("p-6 w-full max-w-lg"):
        ui.label("Longest in stock").classes("text-xl font-bold mb-1")
        ui.label(
            f"Top {limit} non-consignment pieces in stock or reserved, oldest first."
        ).classes("text-sm text-gray-600 mb-4")

        if not items:
            ui.label("No matching items in stock.").classes("text-gray-500")
        else:
            with ui.scroll_area().classes("w-full h-96"):
                with ui.column().classes("w-full gap-2 pr-2"):
                    for index, item in enumerate(items, start=1):
                        with ui.card().classes("p-3 w-full"):
                            ui.label(f"#{index} · {item['days_in_stock']} days in stock").classes(
                                "text-xs text-gray-500"
                            )
                            ui.label(f"#{item['id']} · {item['label']}").classes("font-medium")
                            ui.label(
                                f"Added {_format_item_date(item['added_date'])} · "
                                f"{item['stock']} · {_format_euro(item['sell_price'])}"
                            ).classes("text-sm text-gray-700")

        ui.button("Close", on_click=dialog.close).classes("w-full mt-4").props("no-caps")

    dialog.open()
