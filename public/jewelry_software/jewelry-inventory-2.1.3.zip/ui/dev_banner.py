from nicegui import ui

from config.dev import is_dev_mode
from core.dev_mode_service import clear_local_sign_in


def render_dev_banner() -> None:
    if not is_dev_mode():
        return

    with ui.row().classes(
        "mb-4 w-full items-center justify-between gap-3 rounded bg-amber-100 "
        "text-amber-900 px-3 py-2 text-sm"
    ):
        ui.label(
            "Development mode — auto-signed in, uses local_data/, skips remote kill switch."
        ).classes("grow")

        def switch_to_normal() -> None:
            clear_local_sign_in()
            ui.notify("Switched to normal mode — please sign in.", type="positive")
            ui.navigate.to("/login")

        ui.button("Switch to normal login", on_click=switch_to_normal).props(
            "flat dense no-caps"
        ).classes("text-amber-900")
