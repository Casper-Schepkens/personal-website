"""Shared photo picking helpers."""

from __future__ import annotations

import os
import tkinter as tk
from tkinter import filedialog

from nicegui import ui

from config.settings import IMAGES_TO_ADD_DIR
from core.image_service import (
    get_image_url,
    has_image,
    resolve_photo_source,
)
from ui.photo_display import (
    PHOTO_PROPS,
    PHOTO_STYLE,
    PLACEHOLDER_SRC,
    bind_photo,
    open_image_zoom,
)


def pick_photo_from_folder(*, title: str = "Select photo") -> str | None:
    os.makedirs(IMAGES_TO_ADD_DIR, exist_ok=True)
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        path = filedialog.askopenfilename(
            title=title,
            initialdir=IMAGES_TO_ADD_DIR,
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.gif *.webp *.JPEG *.JPG *.PNG"),
            ],
        )
    finally:
        root.destroy()
    return path or None


def pick_shop_logo_from_folder() -> str | None:
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    try:
        path = filedialog.askopenfilename(
            title="Select shop logo",
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.gif *.webp *.JPEG *.JPG *.PNG"),
            ],
        )
    finally:
        root.destroy()
    return path or None


def render_editable_item_photo(item_id: int, *, selected: dict) -> None:
    def current_preview_source() -> str | None:
        if selected.get("path"):
            return resolve_photo_source(selected["path"])
        if has_image(item_id):
            return get_image_url(item_id)
        return None

    img = ui.image(PLACEHOLDER_SRC).classes(
        "w-full rounded cursor-zoom-in bg-gray-50 mb-2"
    ).style(PHOTO_STYLE).props(PHOTO_PROPS)

    def refresh_preview() -> None:
        source = current_preview_source()
        if not source:
            img.set_source(PLACEHOLDER_SRC)
            return
        bind_photo(img, source)

    def pick_photo() -> None:
        path = pick_photo_from_folder(title=f"Select photo for item #{item_id}")
        if not path:
            return
        selected["path"] = path
        refresh_preview()

    def zoom_photo() -> None:
        source = current_preview_source()
        if source:
            open_image_zoom(source)

    refresh_preview()
    img.on("click", zoom_photo)

    ui.label("Click photo to zoom").classes(
        "text-xs text-gray-500 mb-1 text-center w-full"
    )
    ui.button("Edit photo", on_click=pick_photo).classes("w-full mb-1").props(
        "no-caps outline"
    )
    ui.label("Opens file explorer in assets/images_to_add").classes(
        "text-xs text-gray-500 mb-4 text-center w-full"
    )
