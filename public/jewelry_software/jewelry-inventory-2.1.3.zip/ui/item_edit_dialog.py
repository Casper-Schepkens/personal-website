from collections.abc import Callable
from datetime import datetime

from nicegui import ui
from config.item_options import (
    CERTIFICATE_OPTIONS,
    CONSIGNMENT_OPTIONS,
    ITEM_TYPES,
    METALS,
    STONES,
    STOCK_OPTIONS,
)
from core.image_service import save_image_for_item
from core.inventory_service import remove_item, save_item, sell_item, set_item_photo_path
from ui.photo_helpers import render_editable_item_photo
from ui.sold_congrats_dialog import render_sold_congrats


def _options_with_current(options: list[str], current: str | None) -> list[str]:
    if current and current not in options:
        return [current, *options]
    return options


def _num(value) -> float:
    if value is None or value == "":
        return 0.0
    return float(value)


def _edit_title(item) -> str:
    stone = (item["stone"] or "").strip().lower()
    item_type = item["item_type"] or ""
    if stone == "none":
        return f"{item['metal']} {item_type}".strip()
    return f"{item['stone']} {item_type}".strip()


def _format_date(value: str | None) -> str:
    if not value:
        return "Unknown"
    try:
        return datetime.strptime(value[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        return value


def open_item_edit_dialog(item, on_saved: Callable[[], None] | None = None) -> None:
    item_id = item["id"]
    selected_photo: dict = {"path": None}
    is_sold = (item["stock"] or "").strip().lower() == "sold"
    edit_stock_options = [option for option in STOCK_OPTIONS if option != "sold"]

    with ui.dialog() as dialog, ui.card().classes("p-6 w-full max-w-lg") as edit_card:
        with ui.column().classes("w-full mb-4"):
            ui.label(_edit_title(item)).classes("text-xl font-bold")
            ui.label(f"id: {item_id}").classes("text-sm text-gray-600")
            ui.label(f"Added: {_format_date(item['added_date'])}").classes(
                "text-sm text-gray-600"
            )
            if is_sold:
                ui.label(f"Sold: {_format_date(item['sold_date'])}").classes(
                    "text-sm text-gray-600"
                )

        render_editable_item_photo(item_id, selected=selected_photo)

        item_type_select = ui.select(
            _options_with_current(ITEM_TYPES, item["item_type"]),
            label="Item type",
            value=item["item_type"],
        ).classes("w-full").props("dense outlined")

        weight_input = ui.number(
            "Weight (g)",
            value=_num(item["weight"]),
            format="%.2f",
            min=0,
        ).classes("w-full").props("dense outlined")

        stone_select = ui.select(
            _options_with_current(STONES, item["stone"]),
            label="Stone",
            value=item["stone"],
        ).classes("w-full").props("dense outlined")

        carat_input = ui.number(
            "Carat",
            value=_num(item["carat"]),
            format="%.2f",
            min=0,
        ).classes("w-full").props("dense outlined")

        sidestone_select = ui.select(
            _options_with_current(STONES, item["sidestone"]),
            label="Sidestone",
            value=item["sidestone"],
        ).classes("w-full").props("dense outlined")

        sidestone_carat_input = ui.number(
            "Sidestone carat",
            value=_num(item["sidestone_carat"]),
            format="%.2f",
            min=0,
        ).classes("w-full").props("dense outlined")

        purchase_input = ui.number(
            "Purchase price",
            value=_num(item["purchase_price"]),
            format="%.2f",
            min=0,
        ).classes("w-full").props("dense outlined")

        sell_input = ui.number(
            "Sell price",
            value=_num(item["sell_price"]),
            format="%.2f",
            min=0,
        ).classes("w-full").props("dense outlined")

        metal_select = ui.select(
            _options_with_current(METALS, item["metal"]),
            label="Metal",
            value=item["metal"],
        ).classes("w-full").props("dense outlined")

        if is_sold:
            ui.label("In stock: sold").classes("text-sm text-gray-600")
            stock_select = None
        else:
            stock_select = ui.select(
                _options_with_current(edit_stock_options, item["stock"]),
                label="In stock",
                value=item["stock"],
            ).classes("w-full").props("dense outlined")

        certificate_select = ui.select(
            _options_with_current(CERTIFICATE_OPTIONS, item["certificate"]),
            value=item["certificate"],
            label="Certificate",
        ).classes("w-full").props("dense outlined")

        consignment_select = ui.select(
            _options_with_current(CONSIGNMENT_OPTIONS, item["consignment"] or "no"),
            value=item["consignment"] or "no",
            label="Consignment",
        ).classes("w-full").props("dense outlined")

        def _field_values() -> dict:
            stock = "sold" if is_sold else stock_select.value
            return {
                "item_type": item_type_select.value,
                "weight": _num(weight_input.value),
                "stone": stone_select.value,
                "carat": _num(carat_input.value),
                "sidestone": sidestone_select.value,
                "sidestone_carat": _num(sidestone_carat_input.value),
                "purchase_price": _num(purchase_input.value),
                "sell_price": _num(sell_input.value),
                "metal": metal_select.value,
                "stock": stock,
                "certificate": certificate_select.value,
                "consignment": consignment_select.value or "no",
            }

        def _save_photo() -> None:
            if selected_photo["path"]:
                photo_path = save_image_for_item(item_id, selected_photo["path"])
                set_item_photo_path(item_id, photo_path)

        def confirm_edit() -> None:
            try:
                save_item(item_id, **_field_values())
                _save_photo()
            except (TypeError, ValueError, OSError) as exc:
                ui.notify(f"Invalid values: {exc}", type="negative")
                return

            dialog.close()
            ui.notify("Item updated", type="positive")
            if on_saved:
                on_saved()

        def _persist_sale(values: dict) -> dict | None:
            try:
                save_item(item_id, **values)
                sell_item(item_id)
                _save_photo()
            except (TypeError, ValueError, OSError) as exc:
                ui.notify(f"Invalid values: {exc}", type="negative")
                return None

            return {
                "id": item_id,
                "item_type": values["item_type"],
                "stone": values["stone"],
                "metal": values["metal"],
                "added_date": item["added_date"],
                "purchase_price": values["purchase_price"],
                "sell_price": values["sell_price"],
            }

        def open_sold_price_dialog() -> None:
            with ui.dialog() as sold_dialog, ui.card().classes("p-6 w-full max-w-md") as sold_card:
                ui.label("How much was this piece sold for?").classes(
                    "text-lg font-semibold mb-4"
                )
                sold_price_input = ui.number(
                    value=_num(sell_input.value),
                    format="%.2f",
                    min=0,
                ).classes("w-full").props("dense outlined")

                confirm_btn = ui.button("Confirm").classes(
                    "w-full mt-4 bg-green-600 text-white"
                ).props("no-caps")

                def _finish_sale(sold_item: dict) -> None:
                    sold_dialog.close()

                    def close_congrats() -> None:
                        dialog.close()
                        if on_saved:
                            on_saved()

                    dialog.props("persistent")
                    edit_card.clear()
                    with edit_card:
                        render_sold_congrats(
                            item=sold_item,
                            sell_price=float(sold_item["sell_price"]),
                            on_close=close_congrats,
                        )

                def confirm_sold() -> None:
                    sell_price = _num(sold_price_input.value)
                    confirm_btn.disable()
                    confirm_btn.text = "Saving..."
                    try:
                        values = _field_values()
                        values["sell_price"] = sell_price
                    except (TypeError, ValueError) as exc:
                        ui.notify(f"Invalid values: {exc}", type="negative")
                        confirm_btn.text = "Confirm"
                        confirm_btn.enable()
                        return

                    sold_item = _persist_sale(values)
                    if sold_item is None:
                        confirm_btn.text = "Confirm"
                        confirm_btn.enable()
                        return

                    _finish_sale(sold_item)

                confirm_btn.on_click(confirm_sold)

            sold_dialog.open()

        delete_state = {"armed": False}

        def enable_delete_confirm() -> None:
            if delete_btn.is_deleted:
                return
            delete_btn.enable()

        def handle_delete() -> None:
            if not delete_state["armed"]:
                delete_state["armed"] = True
                delete_btn.text = "CONFIRM"
                delete_btn.disable()
                ui.timer(1.0, enable_delete_confirm, once=True)
                return

            try:
                remove_item(item_id)
            except OSError as exc:
                ui.notify(f"Could not delete item: {exc}", type="negative")
                return

            dialog.close()
            ui.notify(f"Item #{item_id} deleted", type="positive")
            if on_saved:
                on_saved()

        ui.button("Confirm edit", on_click=confirm_edit).classes(
            "w-full mt-6 bg-green-600 text-white"
        ).props("no-caps")

        if not is_sold:
            ui.button("Sold", on_click=open_sold_price_dialog).classes(
                "w-full mt-2 bg-gray-700 text-white"
            ).props("no-caps")

        delete_btn = ui.button("Delete item", on_click=handle_delete).classes(
            "w-full mt-2 bg-red-600 text-white"
        ).props("no-caps")

    dialog.open()
