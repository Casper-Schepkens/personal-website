import hashlib
from dataclasses import dataclass

from core.image_service import get_image_path, has_image
from core.inventory_service import load_inventory

DETAIL_FIELDS = (
    "item_type",
    "weight",
    "stone",
    "carat",
    "sidestone",
    "sidestone_carat",
    "purchase_price",
    "sell_price",
    "metal",
    "stock",
    "certificate",
    "consignment",
)

NUMERIC_FIELDS = {
    "weight",
    "carat",
    "sidestone_carat",
    "purchase_price",
    "sell_price",
}


@dataclass(frozen=True)
class DuplicateGroup:
    reason: str
    item_ids: tuple[int, ...]


def _file_hash(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _normalize_detail_value(value, field: str):
    if field in NUMERIC_FIELDS:
        return round(float(value or 0), 2)
    if value is None:
        return ""
    return str(value).strip().lower()


def _detail_key(item) -> tuple:
    return tuple(_normalize_detail_value(item[field], field) for field in DETAIL_FIELDS)


def _groups_from_buckets(buckets: dict, reason: str) -> list[DuplicateGroup]:
    groups: list[DuplicateGroup] = []
    for item_ids in buckets.values():
        if len(item_ids) > 1:
            groups.append(DuplicateGroup(reason=reason, item_ids=tuple(sorted(item_ids))))
    groups.sort(key=lambda group: group.item_ids)
    return groups


def find_duplicate_groups(items=None) -> list[DuplicateGroup]:
    if items is None:
        items = load_inventory()

    hash_buckets: dict[str, list[int]] = {}
    detail_buckets: dict[tuple, list[int]] = {}

    for item in items:
        item_id = item["id"]
        detail_buckets.setdefault(_detail_key(item), []).append(item_id)

        if has_image(item_id):
            image_hash = _file_hash(get_image_path(item_id))
            hash_buckets.setdefault(image_hash, []).append(item_id)

    groups = _groups_from_buckets(hash_buckets, "image")
    groups.extend(_groups_from_buckets(detail_buckets, "details"))
    return groups


def duplicate_group_count(items=None) -> int:
    return len(find_duplicate_groups(items))
