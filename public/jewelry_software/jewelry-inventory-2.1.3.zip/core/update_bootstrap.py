"""Hand off to updater.py before the app loads (avoids file locks during updates)."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

_SKIP_ENV = "JEWELRY_SKIP_UPDATE_BOOTSTRAP"


def _project_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def _shop_root() -> Path:
    return _project_dir().parent


def _should_auto_update() -> bool:
    if os.environ.get(_SKIP_ENV) == "1":
        return False

    shop_root = _shop_root()
    if not (shop_root / "updater.py").is_file():
        return False

    # Dev repo: ops/ (or legacy admin/) sits next to app/ — skip auto-update there.
    if (shop_root / "ops").is_dir() or (shop_root / "admin").is_dir():
        return False
    # Older nested layout: ops/admin lived one level above shop_root (e.g. …/dev/).
    if (shop_root.parent / "ops").is_dir() or (shop_root.parent / "admin").is_dir():
        return False

    return True


def maybe_delegate_to_updater() -> None:
    """Run updater then start main in a new process; exit so project/ files are unlocked."""
    if not _should_auto_update():
        return

    main_script = _project_dir() / "main.py"
    updater = _shop_root() / "updater.py"
    command = [
        sys.executable,
        str(updater),
        "--update-and-start",
        str(main_script),
        *sys.argv[1:],
    ]
    result = subprocess.run(command, env=os.environ.copy())
    sys.exit(result.returncode)
