import json
from dataclasses import dataclass
from pathlib import Path

from config.settings import SESSION_PATH

ACCOUNT_TYPE_ADMIN = "admin"
ACCOUNT_TYPE_COMPANY = "company"


@dataclass(frozen=True)
class AppSession:
    shop_id: str
    display_name: str
    account_type: str = ACCOUNT_TYPE_COMPANY

    @property
    def is_admin(self) -> bool:
        return self.account_type == ACCOUNT_TYPE_ADMIN

    @property
    def is_company(self) -> bool:
        return self.account_type == ACCOUNT_TYPE_COMPANY


def load_session() -> AppSession | None:
    session_file = Path(SESSION_PATH)
    if not session_file.exists():
        return None

    try:
        data = json.loads(session_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    if not isinstance(data, dict):
        return None

    shop_id = str(data.get("shop_id", "") or "").strip()
    display_name = str(data.get("display_name", "") or shop_id).strip()
    account_type = str(data.get("account_type", "") or ACCOUNT_TYPE_COMPANY).strip()
    if account_type not in {ACCOUNT_TYPE_ADMIN, ACCOUNT_TYPE_COMPANY}:
        account_type = ACCOUNT_TYPE_COMPANY
    if not shop_id:
        return None

    return AppSession(
        shop_id=shop_id,
        display_name=display_name or shop_id,
        account_type=account_type,
    )


def save_session(session: AppSession) -> None:
    session_file = Path(SESSION_PATH)
    session_file.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "shop_id": session.shop_id,
        "display_name": session.display_name,
        "account_type": session.account_type,
    }
    session_file.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def clear_session() -> None:
    session_file = Path(SESSION_PATH)
    if session_file.exists():
        session_file.unlink()
