import os
import re

from PIL import Image, ImageOps

from config.settings import IMAGES_TO_ADD_DIR, PHONE_UPLOAD_DIR

PHONE_IMAGE_EXTENSIONS = {
    ".heic",
    ".heif",
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
    ".gif",
}

_heif_registered = False


def _register_heif() -> None:
    global _heif_registered
    if _heif_registered:
        return
    try:
        import pillow_heif

        pillow_heif.register_heif_opener()
        _heif_registered = True
    except ImportError:
        pass


def _safe_filename(name: str) -> str:
    cleaned = os.path.basename(name)
    cleaned = re.sub(r"[^\w.\-]", "_", cleaned)
    return cleaned or "upload"


def _unique_path(directory: str, filename: str) -> str:
    path = os.path.join(directory, filename)
    if not os.path.exists(path):
        return path

    stem, ext = os.path.splitext(filename)
    counter = 2
    while True:
        candidate = os.path.join(directory, f"{stem}_{counter}{ext}")
        if not os.path.exists(candidate):
            return candidate
        counter += 1


def _unique_png_path(directory: str, stem: str) -> str:
    return _unique_path(directory, f"{stem}.png")


def save_phone_upload(content: bytes, filename: str) -> str:
    os.makedirs(PHONE_UPLOAD_DIR, exist_ok=True)
    safe_name = _safe_filename(filename)
    dest = _unique_path(PHONE_UPLOAD_DIR, safe_name)
    with open(dest, "wb") as handle:
        handle.write(content)
    return dest


def process_phone_uploads() -> tuple[int, list[str]]:
    """Convert phone_upload files to PNG in images_to_add.

    Returns (processed_count, error_messages).
    """
    if not os.path.isdir(PHONE_UPLOAD_DIR):
        return 0, []

    entries = os.listdir(PHONE_UPLOAD_DIR)
    if not entries:
        return 0, []

    _register_heif()
    os.makedirs(IMAGES_TO_ADD_DIR, exist_ok=True)
    processed = 0
    errors: list[str] = []

    for name in entries:
        source = os.path.join(PHONE_UPLOAD_DIR, name)
        if not os.path.isfile(source):
            continue

        ext = os.path.splitext(name)[1].lower()
        if ext not in PHONE_IMAGE_EXTENSIONS:
            continue

        stem = os.path.splitext(name)[0]
        dest = _unique_png_path(IMAGES_TO_ADD_DIR, stem)

        try:
            with Image.open(source) as image:
                upright = ImageOps.exif_transpose(image) or image
                upright.convert("RGB").save(dest, format="PNG", optimize=True)
            os.remove(source)
            processed += 1
        except OSError as exc:
            hint = ""
            if ext in {".heic", ".heif"} and not _heif_registered:
                hint = " (install pillow-heif to support iPhone HEIC photos)"
            errors.append(f"{name}: {exc}{hint}")
            continue

    return processed, errors
