import os

from PIL import Image, ImageOps
from config.settings import (
    IMAGE_DIR,
    IMAGE_URL_PREFIX,
    IMAGES_TO_ADD_DIR,
    STAGING_URL_PREFIX,
    THUMB_DIR,
    THUMB_SIZE,
    THUMB_URL_PREFIX,
)


def _open_image_upright(path: str) -> Image.Image:
    """Open an image and apply EXIF orientation so phone photos are not sideways."""
    image = Image.open(path)
    return ImageOps.exif_transpose(image) or image


def get_image_path(item_id: int) -> str:
    return os.path.join(IMAGE_DIR, f"{item_id}.png")


def get_thumbnail_path(item_id: int) -> str:
    return os.path.join(THUMB_DIR, f"{item_id}.png")


def has_image(item_id: int) -> bool:
    return os.path.exists(get_image_path(item_id))


def has_thumbnail(item_id: int) -> bool:
    return os.path.exists(get_thumbnail_path(item_id))


def get_image_url(item_id: int) -> str | None:
    if has_image(item_id):
        return f"{IMAGE_URL_PREFIX}/{item_id}.png"
    return None


def get_thumbnail_url(item_id: int) -> str | None:
    if has_thumbnail(item_id):
        return f"{THUMB_URL_PREFIX}/{item_id}.png"
    return None


def _is_staging_path(source_path: str) -> bool:
    abs_source = os.path.normcase(os.path.abspath(source_path))
    abs_staging = os.path.normcase(os.path.abspath(IMAGES_TO_ADD_DIR))
    return abs_source.startswith(abs_staging + os.sep)


def resolve_photo_source(source: str) -> str:
    """Return a browser-loadable URL for a photo path or existing URL."""
    if source.startswith(("/", "data:", "http://", "https://")):
        return source
    if os.path.isfile(source) and _is_staging_path(source):
        return f"{STAGING_URL_PREFIX}/{os.path.basename(source)}"
    return source


def create_thumbnail(item_id: int) -> str | None:
    original_path = get_image_path(item_id)
    thumb_path = get_thumbnail_path(item_id)

    if not os.path.exists(original_path):
        return None

    if os.path.exists(thumb_path):
        mtime_thumb = os.path.getmtime(thumb_path)
        mtime_src = os.path.getmtime(original_path)
        if mtime_thumb >= mtime_src:
            return thumb_path

    os.makedirs(os.path.dirname(thumb_path), exist_ok=True)

    img = _open_image_upright(original_path).convert("RGB")
    width, height = img.size
    side = min(width, height)
    left = (width - side) // 2
    top = (height - side) // 2
    img = img.crop((left, top, left + side, top + side))
    img = img.resize(THUMB_SIZE, Image.Resampling.LANCZOS)
    img.save(thumb_path, optimize=True, quality=70)

    return thumb_path


def save_image_for_item(item_id: int, source_path: str) -> str:
    if not os.path.isfile(source_path):
        raise FileNotFoundError(f"Image not found: {source_path}")

    dest = get_image_path(item_id)
    os.makedirs(os.path.dirname(dest), exist_ok=True)

    img = _open_image_upright(source_path).convert("RGB")
    img.save(dest, optimize=True, quality=95)

    thumb_path = get_thumbnail_path(item_id)
    if os.path.exists(thumb_path):
        os.remove(thumb_path)
    create_thumbnail(item_id)

    if _is_staging_path(source_path):
        os.remove(source_path)

    return dest


def save_image_from_staging(item_id: int, staging_filename: str) -> str:
    src = os.path.join(IMAGES_TO_ADD_DIR, staging_filename)
    return save_image_for_item(item_id, src)


def delete_item_images(item_id: int) -> None:
    for path in (get_image_path(item_id), get_thumbnail_path(item_id)):
        if os.path.exists(path):
            os.remove(path)


def create_missing_thumbnails(item_ids: list[int]) -> int:
    created = 0
    for item_id in item_ids:
        if not has_thumbnail(item_id) and create_thumbnail(item_id):
            created += 1
    return created
