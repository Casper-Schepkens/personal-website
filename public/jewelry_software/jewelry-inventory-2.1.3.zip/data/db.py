import sqlite3

from config.settings import DB_PATH

ITEMS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    photo_path TEXT,
    item_type TEXT,
    weight REAL,
    stone TEXT,
    carat REAL,
    sidestone TEXT,
    sidestone_carat REAL,
    purchase_price REAL,
    sell_price REAL,
    metal TEXT,
    stock TEXT,
    certificate TEXT,
    consignment TEXT NOT NULL DEFAULT 'no',
    added_date TEXT,
    sold_date TEXT
)
"""


def _ensure_schema(conn: sqlite3.Connection) -> None:
    cursor = conn.cursor()
    cursor.execute(ITEMS_TABLE_SQL)

    cursor.execute("PRAGMA table_info(items)")
    columns = {row[1] for row in cursor.fetchall()}
    if "consignment" not in columns:
        cursor.execute(
            "ALTER TABLE items ADD COLUMN consignment TEXT NOT NULL DEFAULT 'no'"
        )
    if "added_date" not in columns:
        cursor.execute("ALTER TABLE items ADD COLUMN added_date TEXT")
    if "sold_date" not in columns:
        cursor.execute("ALTER TABLE items ADD COLUMN sold_date TEXT")
    conn.commit()


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    _ensure_schema(conn)
    return conn
