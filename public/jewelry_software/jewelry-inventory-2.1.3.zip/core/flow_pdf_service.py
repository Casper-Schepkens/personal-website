"""Build a PDF report for the Flow page."""

from __future__ import annotations

from datetime import date, datetime
from io import BytesIO

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from fpdf import FPDF

from core.flow_service import format_net_items, item_label, item_profit, load_flow_data


def flow_pdf_filename(period_start: date, period_end: date) -> str:
    start = period_start.strftime("%Y%m%d")
    end = period_end.strftime("%Y%m%d")
    return f"jewelry_flow_{start}_{end}.pdf"


def _euro(amount: float) -> str:
    return f"EUR {int(round(amount)):,}"


def _comparison_text(current: float, previous: float) -> str:
    diff = current - previous
    sign = "+" if diff > 0 else ""
    if previous:
        pct = (diff / previous) * 100
        return f"{sign}{int(round(diff))} vs previous ({pct:+.0f}%)"
    return f"{sign}{int(round(diff))} vs previous"


def _figure_to_bytes(fig) -> bytes:
    buffer = BytesIO()
    fig.savefig(buffer, format="png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    buffer.seek(0)
    return buffer.getvalue()


def _flow_bar_chart_png(flow: dict) -> bytes:
    chart = flow["chart"]
    fig, ax1 = plt.subplots(figsize=(8, 3.5))
    x = range(len(chart["labels"]))
    width = 0.35
    ax1.bar([i - width / 2 for i in x], chart["added_counts"], width, label="Items in")
    ax1.bar([i + width / 2 for i in x], chart["sold_counts"], width, label="Items out")
    ax1.set_xticks(list(x))
    ax1.set_xticklabels(chart["labels"], rotation=45, ha="right")
    ax1.set_ylabel("Items")
    ax1.legend(loc="upper left")

    ax2 = ax1.twinx()
    ax2.plot(list(x), chart["profit_totals"], color="green", marker="o", label="Profit")
    ax2.set_ylabel("Profit (EUR)")
    fig.tight_layout()
    return _figure_to_bytes(fig)


def _pie_chart_png(data: dict[str, float], title: str) -> bytes | None:
    filtered = {key: value for key, value in data.items() if value > 0}
    if not filtered:
        return None

    fig, ax = plt.subplots(figsize=(4.5, 4.5))
    ax.pie(
        list(filtered.values()),
        labels=list(filtered.keys()),
        autopct="%1.0f%%",
        startangle=90,
    )
    ax.set_title(title)
    fig.tight_layout()
    return _figure_to_bytes(fig)


class _FlowPDF(FPDF):
    def header(self) -> None:
        self.set_font("Helvetica", "B", 14)
        self.cell(0, 10, "Flow report", new_x="LMARGIN", new_y="NEXT")

    def section_title(self, title: str) -> None:
        self.set_font("Helvetica", "B", 11)
        self.cell(0, 8, title, new_x="LMARGIN", new_y="NEXT")
        self.ln(1)

    def body_line(self, text: str) -> None:
        self.set_font("Helvetica", "", 10)
        self.cell(0, 6, text, new_x="LMARGIN", new_y="NEXT")


def _daily_profit_chart_png(profit_charts: dict, *, cumulative: bool = False) -> bytes:
    labels = profit_charts["labels"]
    values = (
        profit_charts["cumulative_profit"]
        if cumulative
        else profit_charts["daily_profit"]
    )
    title = "Cumulative profit" if cumulative else "Profit by day"
    fig, ax = plt.subplots(figsize=(6, 3.5))
    if cumulative:
        ax.plot(range(len(labels)), values, color="green", marker="o")
    else:
        ax.bar(range(len(labels)), values)
    ax.set_title(title)
    ax.set_xticks(range(len(labels)))
    step = max(1, len(labels) // 12)
    ax.set_xticklabels(
        [label if index % step == 0 else "" for index, label in enumerate(labels)],
        rotation=45,
        ha="right",
    )
    ax.set_ylabel("Profit (EUR)")
    fig.tight_layout()
    return _figure_to_bytes(fig)


def _margin_pie_png(breakdown: dict) -> bytes | None:
    data = {
        name: pct
        for name, pct in breakdown.get("margin_pct", {}).items()
        if breakdown["revenue"].get(name, 0) > 0
    }
    if not data:
        return None
    return _pie_chart_png(data, "Margin by type (%)")


def build_flow_pdf(
    *,
    period_mode: str = "month",
    item_type: str = "All",
    custom_start: date | None = None,
    custom_end: date | None = None,
    selected_month: str | None = None,
    selected_year: int | None = None,
    shop_name: str | None = None,
) -> bytes:
    flow = load_flow_data(
        period_mode,
        item_type=item_type,
        custom_start=custom_start,
        custom_end=custom_end,
        selected_month=selected_month,
        selected_year=selected_year,
    )
    summary = flow["summary"]
    comparison = flow["comparison"]
    pdf = _FlowPDF()
    pdf.set_auto_page_break(auto=True, margin=12)
    pdf.add_page()

    pdf.body_line(f"Shop: {shop_name or '-'}")
    pdf.body_line(f"Exported: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    pdf.body_line(
        f"Period: {flow['period_start'].isoformat()} to {flow['period_end'].isoformat()}"
    )
    pdf.body_line(f"Type filter: {item_type}")
    pdf.body_line("Consignment items excluded")
    pdf.ln(3)

    pdf.section_title("Summary")
    pdf.body_line(f"Added items: {summary['added_count']}")
    pdf.body_line(f"Sold items: {summary['sold_count']}")
    pdf.body_line(f"Net items: {format_net_items(summary['added_count'], summary['sold_count'])}")
    pdf.body_line(f"Sold revenue: {_euro(summary['sold_sell_total'])}")
    pdf.body_line(f"Sold profit: {_euro(summary['sold_profit_total'])}")
    cash = summary["cash"]
    pdf.body_line(f"Cash in (sales): {_euro(cash['cash_in'])}")
    pdf.body_line(f"Cash out (purchases): {_euro(cash['cash_out'])}")
    pdf.body_line(f"Net cash: {_euro(cash['net_cash'])}")
    outcomes = summary.get("added_outcomes") or {}
    if outcomes.get("total"):
        pdf.body_line(
            "Added since: "
            f"{outcomes.get('sold', 0)} sold · "
            f"{outcomes.get('in_stock', 0)} in stock · "
            f"{outcomes.get('reserved', 0)} reserved"
        )
    if summary.get("sold_margin_pct") is not None:
        pdf.body_line(f"Sold margin: {summary['sold_margin_pct']:.0f}%")
    avg_days = summary["average_days_to_sell"]
    if avg_days is None:
        pdf.body_line("Average time to sell: -")
    else:
        pdf.body_line(f"Average time to sell: {avg_days:.0f} days")
    pdf.ln(2)

    pdf.section_title("Vs previous period")
    pdf.body_line(
        "Sold profit: "
        f"{_comparison_text(comparison['sold_profit']['current'], comparison['sold_profit']['previous'])}"
    )
    pdf.body_line(
        "Sold revenue: "
        f"{_comparison_text(comparison['sold_revenue']['current'], comparison['sold_revenue']['previous'])}"
    )
    pdf.body_line(
        "Sold items: "
        f"{_comparison_text(comparison['sold_count']['current'], comparison['sold_count']['previous'])}"
    )
    pdf.body_line(
        "Net cash: "
        f"{_comparison_text(comparison['net_cash']['current'], comparison['net_cash']['previous'])}"
    )
    pdf.ln(3)

    flow_chart = _flow_bar_chart_png(flow)
    pdf.section_title("Flow chart")
    pdf.image(BytesIO(flow_chart), w=190)
    pdf.ln(3)

    profit_charts = flow["profit_charts"]
    daily_chart = _daily_profit_chart_png(profit_charts, cumulative=False)
    cumulative_chart = _daily_profit_chart_png(profit_charts, cumulative=True)
    pdf.add_page()
    pdf.section_title("Profit charts")
    pdf.image(BytesIO(daily_chart), x=10, y=pdf.get_y(), w=90)
    pdf.image(BytesIO(cumulative_chart), x=110, y=pdf.get_y(), w=90)
    pdf.ln(95)

    breakdown = flow["type_breakdown"]
    revenue_png = _pie_chart_png(breakdown["revenue"], "Revenue by type")
    profit_png = _pie_chart_png(breakdown["profit"], "Profit by type")
    margin_png = _margin_pie_png(breakdown)
    if revenue_png or profit_png or margin_png:
        pdf.add_page()
        pdf.section_title("Breakdown by type")
        y = pdf.get_y()
        x_positions = [10, 75, 140]
        for index, png in enumerate([revenue_png, profit_png, margin_png]):
            if png:
                pdf.image(BytesIO(png), x=x_positions[index], y=y, w=60)

    pdf.add_page()
    pdf.section_title("Items in")
    for item in flow["added_items"][:40]:
        pdf.body_line(
            f"{item['added_date']}  #{item['id']}  {item_label(item)}  "
            f"{_euro(float(item['sell_price'] or 0))}"
        )
    if len(flow["added_items"]) > 40:
        pdf.body_line(f"... and {len(flow['added_items']) - 40} more")

    pdf.ln(3)
    pdf.section_title("Items out")
    for item in flow["sold_items"][:40]:
        pdf.body_line(
            f"{item['sold_date']}  #{item['id']}  {item_label(item)}  "
            f"{_euro(float(item['sell_price'] or 0))}  "
            f"profit {_euro(item_profit(item))}"
        )
    if len(flow["sold_items"]) > 40:
        pdf.body_line(f"... and {len(flow['sold_items']) - 40} more")

    buffer = BytesIO()
    pdf.output(buffer)
    return buffer.getvalue()
