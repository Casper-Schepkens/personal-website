from nicegui import ui

PLACEHOLDER_SRC = (
    "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
)
PHOTO_STYLE = "width: 100%; height: 18rem; min-height: 12rem;"
ZOOM_STYLE = "width: 90vw; height: 85vh; max-width: 95vw; max-height: 90vh;"
PHOTO_PROPS = "fit=contain"


def bind_photo(img: ui.image, url: str, *, delay: float = 0.05) -> None:
    """Load photo after the dialog is visible (q-img often skips load while hidden)."""

    def apply_source() -> None:
        if img.is_deleted:
            return
        img.set_source(url)

    ui.timer(delay, apply_source, once=True)


def bind_photo_on_dialog_show(img: ui.image, url: str, dialog: ui.dialog) -> None:
    """Load photo after a (nested) dialog is shown — q-img skips load while hidden."""

    def apply_source() -> None:
        if img.is_deleted:
            return
        img.set_source(url)

    dialog.on("show", lambda: ui.timer(0.05, apply_source, once=True))


def open_image_zoom(url: str) -> None:
    with ui.dialog() as zoom_dialog:
        zoom_dialog.props("maximized")

        def close_zoom() -> None:
            zoom_dialog.close()

        with ui.card().classes(
            "p-2 bg-black/95 flex items-center justify-center w-full h-full "
            "min-h-screen shadow-none cursor-pointer"
        ).style("max-width: 100vw; box-shadow: none;") as backdrop:
            backdrop.on("click", close_zoom)
            zoom_img = ui.image(PLACEHOLDER_SRC).style(ZOOM_STYLE).props(PHOTO_PROPS).classes(
                "cursor-pointer"
            )
            zoom_img.on("click", close_zoom)
            bind_photo_on_dialog_show(zoom_img, url, zoom_dialog)
        zoom_dialog.open()
