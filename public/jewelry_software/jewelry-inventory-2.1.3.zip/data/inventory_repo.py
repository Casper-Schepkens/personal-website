import sqlite3
from datetime import date

from data.db import get_connection

FILTER_COLUMNS = ("item_type", "metal", "stone", "sidestone", "stock", "consignment")
CONSIGNMENT_FILTER_VALUES = ("yes", "no")


def _is_consignment_sql() -> str:
    """Consignment flag yes, or legacy buy-price-zero marker."""
    return (
        "(LOWER(TRIM(COALESCE(consignment, ''))) = 'yes' "
        "OR COALESCE(purchase_price, 0) = 0)"
    )


def _exclude_consignment_clause() -> str:
    """Owned stock only (used by stats, flow, export)."""
    return f"(NOT {_is_consignment_sql()})"


def _consignment_filter_clause(value: str) -> str | None:
    cleaned = (value or "").strip().lower()
    if cleaned == "yes":
        return _is_consignment_sql()
    if cleaned == "no":
        return _exclude_consignment_clause()
    return None


def _build_where(
    filters: dict,
    exclude: str | None = None,
    *,
    item_id: int | None = None,
    price_min: float | None = None,
    price_max: float | None = None,
    force_exclude_consignment: bool = False,
) -> tuple[str, list]:
    clauses = ["1=1"]
    params: list = []

    for column in FILTER_COLUMNS:
        if column == exclude:
            continue
        value = filters.get(column)
        if not value or value == "All":
            continue
        if column == "consignment":
            if force_exclude_consignment:
                continue
            clause = _consignment_filter_clause(str(value))
            if clause:
                clauses.append(clause)
            continue
        clauses.append(f"{column} = ?")
        params.append(value)

    if force_exclude_consignment:
        clauses.append(_exclude_consignment_clause())

    if item_id is not None:
        clauses.append("id = ?")
        params.append(item_id)

    if price_min is not None:
        clauses.append("COALESCE(sell_price, 0) >= ?")
        params.append(price_min)
    if price_max is not None:
        clauses.append("COALESCE(sell_price, 0) <= ?")
        params.append(price_max)

    return " AND ".join(clauses), params


def get_sell_price_bounds() -> tuple[float, float]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT COALESCE(MIN(sell_price), 0), COALESCE(MAX(sell_price), 0)
        FROM items
        WHERE {_exclude_consignment_clause()}
        """
    )
    row = cursor.fetchone()
    conn.close()
    return float(row[0] or 0), float(row[1] or 0)


def get_value_counts(
    column: str,
    *,
    item_id: int | None = None,
    price_min: float | None = None,
    price_max: float | None = None,
    **filters,
) -> list[tuple[str, int]]:
    if column not in FILTER_COLUMNS:
        raise ValueError(f"Invalid filter column: {column}")

    where, params = _build_where(
        filters,
        exclude=column,
        item_id=item_id,
        price_min=price_min,
        price_max=price_max,
    )

    conn = get_connection()
    cursor = conn.cursor()

    if column == "consignment":
        cursor.execute(
            f"""
            SELECT
                SUM(CASE WHEN {_is_consignment_sql()} THEN 1 ELSE 0 END) AS yes_cnt,
                SUM(CASE WHEN {_exclude_consignment_clause()} THEN 1 ELSE 0 END) AS no_cnt
            FROM items
            WHERE {where}
            """,
            params,
        )
        row = cursor.fetchone()
        conn.close()
        return [
            ("yes", int(row[0] or 0)),
            ("no", int(row[1] or 0)),
        ]

    cursor.execute(
        f"""
        SELECT {column}, COUNT(*) AS cnt
        FROM items
        WHERE {where}
          AND {column} IS NOT NULL AND TRIM({column}) != ''
        GROUP BY {column}
        ORDER BY {column}
        """,
        params,
    )
    rows = [(row[0], row[1]) for row in cursor.fetchall()]
    conn.close()
    return rows


def get_filtered_count(
    exclude: str | None = None,
    *,
    item_id: int | None = None,
    price_min: float | None = None,
    price_max: float | None = None,
    **filters,
) -> int:
    where, params = _build_where(
        filters,
        exclude=exclude,
        item_id=item_id,
        price_min=price_min,
        price_max=price_max,
    )

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(f"SELECT COUNT(*) FROM items WHERE {where}", params)
    count = cursor.fetchone()[0]
    conn.close()
    return count


def get_items(
    item_type: str | None = None,
    metal: str | None = None,
    stone: str | None = None,
    sidestone: str | None = None,
    stock: str | None = None,
    consignment: str | None = None,
    item_id: int | None = None,
    price_min: float | None = None,
    price_max: float | None = None,
):
    filters = {
        "item_type": item_type,
        "metal": metal,
        "stone": stone,
        "sidestone": sidestone,
        "stock": stock,
        "consignment": consignment,
    }
    where, params = _build_where(
        filters,
        item_id=item_id,
        price_min=price_min,
        price_max=price_max,
    )

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM items WHERE {where} ORDER BY id", params)
    rows = cursor.fetchall()
    conn.close()
    return rows


def get_inventory_stats(
    item_type: str | None = None,
    metal: str | None = None,
    stone: str | None = None,
    sidestone: str | None = None,
    stock: str | None = None,
    consignment: str | None = None,
    item_id: int | None = None,
    price_min: float | None = None,
    price_max: float | None = None,
) -> dict:
    # Overview always excludes consignments (and legacy buy-price-zero),
    # regardless of the consignment filter on the grid.
    filters = {
        "item_type": item_type,
        "metal": metal,
        "stone": stone,
        "sidestone": sidestone,
        "stock": stock,
        "consignment": None,
    }
    where, params = _build_where(
        filters,
        item_id=item_id,
        price_min=price_min,
        price_max=price_max,
        force_exclude_consignment=True,
    )

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT
            COUNT(*) AS item_count,
            SUM(CASE WHEN LOWER(TRIM(stock)) = 'in stock' THEN 1 ELSE 0 END) AS in_stock_count,
            COALESCE(SUM(purchase_price), 0) AS buy_total,
            COALESCE(SUM(sell_price), 0) AS sell_total,
            COALESCE(SUM(weight), 0) AS weight_total
        FROM items
        WHERE {where}
        """,
        params,
    )
    row = cursor.fetchone()
    conn.close()

    buy_total = row["buy_total"] or 0
    sell_total = row["sell_total"] or 0

    return {
        "item_count": row["item_count"] or 0,
        "in_stock_count": row["in_stock_count"] or 0,
        "buy_total": buy_total,
        "sell_total": sell_total,
        "profit_total": sell_total - buy_total,
        "weight_total": row["weight_total"] or 0,
    }


def get_item_by_id(item_id: int):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM items WHERE id = ?", (item_id,))
    row = cursor.fetchone()
    conn.close()
    return row


def update_item(
    item_id: int,
    *,
    item_type: str,
    weight: float,
    stone: str,
    carat: float,
    sidestone: str,
    sidestone_carat: float,
    purchase_price: float,
    sell_price: float,
    metal: str,
    stock: str,
    certificate: str,
    consignment: str,
) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        UPDATE items SET
            item_type = ?,
            weight = ?,
            stone = ?,
            carat = ?,
            sidestone = ?,
            sidestone_carat = ?,
            purchase_price = ?,
            sell_price = ?,
            metal = ?,
            stock = ?,
            certificate = ?,
            consignment = ?
        WHERE id = ?
        """,
        (
            item_type,
            weight,
            stone,
            carat,
            sidestone,
            sidestone_carat,
            purchase_price,
            sell_price,
            metal,
            stock,
            certificate,
            consignment,
            item_id,
        ),
    )
    conn.commit()
    conn.close()


def insert_item(
    *,
    item_type: str,
    weight: float,
    stone: str,
    carat: float,
    sidestone: str,
    sidestone_carat: float,
    purchase_price: float,
    sell_price: float,
    metal: str,
    stock: str,
    certificate: str,
    consignment: str = "no",
    photo_path: str | None = None,
) -> int:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO items (
            photo_path, item_type, weight, stone, carat,
            sidestone, sidestone_carat, purchase_price, sell_price,
            metal, stock, certificate, consignment, added_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            photo_path,
            item_type,
            weight,
            stone,
            carat,
            sidestone,
            sidestone_carat,
            purchase_price,
            sell_price,
            metal,
            stock,
            certificate,
            consignment,
            date.today().isoformat(),
        ),
    )
    item_id = cursor.lastrowid
    conn.commit()
    conn.close()
    return item_id


def mark_item_sold(item_id: int) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE items SET stock = ?, sold_date = ? WHERE id = ?",
        ("sold", date.today().isoformat(), item_id),
    )
    conn.commit()
    conn.close()


def update_photo_path(item_id: int, photo_path: str) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE items SET photo_path = ? WHERE id = ?", (photo_path, item_id))
    conn.commit()
    conn.close()


def delete_item(item_id: int) -> None:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM items WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()


def get_all_items_for_export() -> list:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        f"SELECT * FROM items WHERE {_exclude_consignment_clause()} ORDER BY id"
    )
    rows = cursor.fetchall()
    conn.close()
    return rows


def _dated_items_clause(date_column: str) -> str:
    return (
        f"{date_column} IS NOT NULL AND TRIM({date_column}) != '' "
        f"AND LENGTH(TRIM({date_column})) >= 10"
    )


def get_items_by_date_column(
    date_column: str,
    start: str,
    end: str,
    *,
    item_type: str | None = None,
) -> list:
    if date_column not in ("added_date", "sold_date"):
        raise ValueError(f"Invalid date column: {date_column}")

    clauses = [
        _dated_items_clause(date_column),
        f"DATE({date_column}) >= DATE(?)",
        f"DATE({date_column}) <= DATE(?)",
        _exclude_consignment_clause(),
    ]
    params: list = [start, end]

    if item_type and item_type != "All":
        clauses.append("item_type = ?")
        params.append(item_type)

    where = " AND ".join(clauses)
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        f"SELECT * FROM items WHERE {where} ORDER BY DATE({date_column}) DESC, id DESC",
        params,
    )
    rows = cursor.fetchall()
    conn.close()
    return rows


def get_longest_in_stock_items(
    *,
    item_type: str | None = None,
    limit: int = 25,
) -> list:
    clauses = [
        _dated_items_clause("added_date"),
        "LOWER(TRIM(stock)) IN ('in stock', 'reserved')",
        _exclude_consignment_clause(),
    ]
    params: list = []

    if item_type and item_type != "All":
        clauses.append("item_type = ?")
        params.append(item_type)

    where = " AND ".join(clauses)
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        f"""
        SELECT * FROM items
        WHERE {where}
        ORDER BY DATE(added_date) ASC, id ASC
        LIMIT ?
        """,
        (*params, limit),
    )
    rows = cursor.fetchall()
    conn.close()
    return rows
