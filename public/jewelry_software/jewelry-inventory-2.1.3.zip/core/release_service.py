"""Create release zips and manage the app version in config/settings.py."""

from __future__ import annotations

import json
import os
import re
import shutil
import zipfile
from datetime import datetime
from pathlib import Path

from config.settings import APP_ID, BASE_DIR, HOSTING_DIR, LICENSE_JSON_PATH

PROJECT_ROOT = Path(BASE_DIR)
SETTINGS_PATH = PROJECT_ROOT / "config" / "settings.py"
RELEASE_OUTPUT_DIR = Path(HOSTING_DIR) / "releases"
HOSTING_LICENSE_PATH = Path(HOSTING_DIR) / "license.json"

VERSION_PATTERN = re.compile(r"^(\d+)\.(\d+)\.(\d+)$")
SETTINGS_VERSION_PATTERN = re.compile(
    r'^APP_VERSION\s*=\s*["\']([^"\']+)["\']',
    re.MULTILINE,
)

EXCLUDED_TOP_LEVEL_DIRS = {"local_data", "local_files"}
EXCLUDED_DIR_NAMES = {"__pycache__", ".git", ".cursor"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".zip"}


def read_app_version() -> str:
    content = SETTINGS_PATH.read_text(encoding="utf-8")
    match = SETTINGS_VERSION_PATTERN.search(content)
    if not match:
        raise ValueError("APP_VERSION not found in config/settings.py")
    return match.group(1)


def validate_version(version: str) -> str:
    cleaned = version.strip()
    if not VERSION_PATTERN.fullmatch(cleaned):
        raise ValueError("Version must be in the form major.minor.patch (e.g. 2.1.0)")
    return cleaned


def compare_versions(left: str, right: str) -> int:
    left_parts = [int(part) for part in validate_version(left).split(".")]
    right_parts = [int(part) for part in validate_version(right).split(".")]
    if left_parts > right_parts:
        return 1
    if left_parts < right_parts:
        return -1
    return 0


def write_app_version(version: str) -> str:
    cleaned = validate_version(version)
    content = SETTINGS_PATH.read_text(encoding="utf-8")
    if not SETTINGS_VERSION_PATTERN.search(content):
        raise ValueError("APP_VERSION not found in config/settings.py")

    updated = SETTINGS_VERSION_PATTERN.sub(
        f'APP_VERSION = "{cleaned}"',
        content,
        count=1,
    )
    SETTINGS_PATH.write_text(updated, encoding="utf-8")
    return cleaned


def _relative_path(path: Path) -> str:
    return path.relative_to(PROJECT_ROOT).as_posix()


def _should_include(path: Path) -> bool:
    relative = _relative_path(path)
    parts = Path(relative).parts

    if parts and parts[0] in EXCLUDED_TOP_LEVEL_DIRS:
        return False

    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return False

    if any(part in EXCLUDED_DIR_NAMES for part in parts):
        return False

    return True


def _collect_files() -> list[Path]:
    files: list[Path] = []
    for root, dirnames, filenames in os.walk(PROJECT_ROOT):
        root_path = Path(root)
        dirnames[:] = [
            name
            for name in dirnames
            if name not in EXCLUDED_DIR_NAMES
            and _relative_path(root_path / name).split(os.sep)[0] not in EXCLUDED_TOP_LEVEL_DIRS
        ]

        for filename in filenames:
            file_path = root_path / filename
            if _should_include(file_path):
                files.append(file_path)

    return sorted(files)


def build_release_zip(version: str | None = None) -> tuple[Path, str, int]:
    if version is not None:
        write_app_version(version)

    app_version = read_app_version()
    RELEASE_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    zip_name = f"{APP_ID}-{app_version}.zip"
    zip_path = RELEASE_OUTPUT_DIR / zip_name
    files = _collect_files()
    if not files:
        raise RuntimeError("No files matched the release rules.")

    if zip_path.exists():
        zip_path.unlink()

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for file_path in files:
            archive.write(file_path, _relative_path(file_path))

    return zip_path, app_version, len(files)


def release_upload_url(zip_name: str) -> str:
    return f"https://casperschepkens.com/jewelry_software/{zip_name}"


def license_upload_url() -> str:
    return "https://casperschepkens.com/jewelry_software/license.json"


def sync_license_to_hosting() -> Path:
    """Copy ops/license.json to hosting/license.json for website upload (no field changes)."""
    license_path = Path(LICENSE_JSON_PATH)
    if not license_path.is_file():
        raise FileNotFoundError(f"Missing {license_path}")
    Path(HOSTING_DIR).mkdir(parents=True, exist_ok=True)
    shutil.copy2(license_path, HOSTING_LICENSE_PATH)
    return HOSTING_LICENSE_PATH


def sync_license_latest_version(version: str | None = None) -> Path:
    """Write latest_version into ops/license.json and copy to hosting/ for upload."""
    cleaned = validate_version(version) if version else read_app_version()
    license_path = Path(LICENSE_JSON_PATH)
    if not license_path.is_file():
        raise FileNotFoundError(f"Missing {license_path}")

    data = json.loads(license_path.read_text(encoding="utf-8").lstrip("\ufeff"))
    if not isinstance(data, dict):
        raise ValueError("License JSON root must be an object.")
    data["latest_version"] = cleaned
    license_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return sync_license_to_hosting()


def prepare_release_for_hosting(version: str | None = None) -> dict:
    """Build zip, stamp license latest_version, stage hosting/ files for website upload."""
    zip_path, app_version, file_count = build_release_zip(version)
    hosting_license = sync_license_latest_version(app_version)
    return {
        "zip_path": zip_path,
        "version": app_version,
        "file_count": file_count,
        "hosting_license": hosting_license,
        "zip_url": release_upload_url(zip_path.name),
        "license_url": license_upload_url(),
    }


def format_build_summary(zip_path: Path, version: str, file_count: int) -> str:
    built_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return (
        f"Built {zip_path.name} at {built_at}\n"
        f"Version: {version}\n"
        f"Files included: {file_count}\n"
        f"Upload zip to: {release_upload_url(zip_path.name)}\n"
        f"Upload license to: {license_upload_url()}"
    )
