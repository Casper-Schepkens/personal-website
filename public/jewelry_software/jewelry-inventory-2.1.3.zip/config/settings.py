import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Dev repo uses ``app/``; client installs and test layouts use ``project/``.
_APP_DIR_NAMES = frozenset({"app", "project"})
# Dev repo marker folder (was historically named ``admin/``).
_OPS_DIR_NAMES = ("ops", "admin")


def _is_nested_app_dir(path: str) -> bool:
    return os.path.basename(path) in _APP_DIR_NAMES


def _workspace_dir() -> str:
    """Folder that contains ops/ (repo root), or parent of the app folder."""
    start = os.path.dirname(BASE_DIR) if _is_nested_app_dir(BASE_DIR) else BASE_DIR
    current = start
    while True:
        if any(os.path.isdir(os.path.join(current, name)) for name in _OPS_DIR_NAMES):
            return current
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    return start


def _ops_dir(workspace: str) -> str:
    for name in _OPS_DIR_NAMES:
        candidate = os.path.join(workspace, name)
        if os.path.isdir(candidate):
            return candidate
    return os.path.join(workspace, "ops")


WORKSPACE_DIR = _workspace_dir()
OPS_DIR = _ops_dir(WORKSPACE_DIR)
ADMIN_DIR = OPS_DIR  # backward-compatible alias
HOSTING_DIR = os.path.join(WORKSPACE_DIR, "hosting")
LICENSE_JSON_PATH = os.path.join(OPS_DIR, "license.json")


def _default_local_data_dir() -> str:
    """Resolve local data folder.

    - App in an ``app/`` or ``project/`` folder: sibling ``../local_data``
    - Flat client install (main.py at shop root): ``./local_data``
    - Legacy: ``./local_files`` if present
    """
    parent = os.path.dirname(BASE_DIR)
    if _is_nested_app_dir(BASE_DIR):
        return os.path.join(parent, "local_data")

    local_data = os.path.join(BASE_DIR, "local_data")
    legacy = os.path.join(BASE_DIR, "local_files")
    if os.path.isdir(legacy) and not os.path.isdir(local_data):
        return legacy
    return local_data


LOCAL_DATA_DIR = os.environ.get("JEWELRY_LOCAL_FILES", _default_local_data_dir())
# Backward-compatible alias used across the codebase
LOCAL_FILES_DIR = LOCAL_DATA_DIR

DB_PATH = os.path.join(LOCAL_DATA_DIR, "jewelry.db")
IMAGE_DIR = os.path.join(LOCAL_DATA_DIR, "assets", "images")
THUMB_DIR = os.path.join(LOCAL_DATA_DIR, "assets", "thumbs")
IMAGES_TO_ADD_DIR = os.path.join(LOCAL_DATA_DIR, "assets", "images_to_add")
PHONE_UPLOAD_DIR = os.path.join(LOCAL_DATA_DIR, "assets", "phone_upload")
BRANDING_DIR = os.path.join(LOCAL_DATA_DIR, "assets", "branding")
SHOP_LOGO_FILENAME = "shop_logo.png"
SHOP_LOGO_PATH = os.path.join(BRANDING_DIR, SHOP_LOGO_FILENAME)
SESSION_PATH = os.path.join(LOCAL_DATA_DIR, "session.json")
DEV_SETTINGS_PATH = os.path.join(LOCAL_DATA_DIR, "dev_settings.py")

THUMB_URL_PREFIX = "/thumbs"
IMAGE_URL_PREFIX = "/photos"
STAGING_URL_PREFIX = "/staging-photos"
SHOP_LOGO_URL_PREFIX = "/shop-logo"
APP_HOST = "0.0.0.0"
APP_PORT = int(os.environ.get("JEWELRY_APP_PORT", "8080"))
ADMIN_PORT = 8081
APP_ID = "jewelry-inventory"
APP_VERSION = "2.1.3"
APP_DISPLAY_NAME = "Jewelry Inventory"
LICENSE_JSON_URL = os.environ.get(
    "JEWELRY_LICENSE_URL",
    "https://casperschepkens.com/jewelry_software/license.json",
)
LICENSE_FETCH_TIMEOUT_SECONDS = 10
LICENSE_BLOCK_MESSAGE = "License not valid. Contact Casper."
THUMB_SIZE = (400, 400)
PAGE_SIZE = 32

os.makedirs(LOCAL_DATA_DIR, exist_ok=True)
os.makedirs(IMAGE_DIR, exist_ok=True)
os.makedirs(THUMB_DIR, exist_ok=True)
os.makedirs(IMAGES_TO_ADD_DIR, exist_ok=True)
os.makedirs(PHONE_UPLOAD_DIR, exist_ok=True)
os.makedirs(BRANDING_DIR, exist_ok=True)

CLIENT_README_PATH = os.path.join(LOCAL_DATA_DIR, "README.txt")
CLIENT_README_TEXT = """Your local data folder. Do not delete.

jewelry.db          Your inventory database
session.json        Login session (created after sign-in)
assets/images/      Product photos
assets/thumbs/      Thumbnails (auto-generated)
assets/images_to_add/   Staging folder for new photos
assets/phone_upload/    Temporary phone uploads
assets/branding/        Shop logo (shop_logo.png)

This folder is never replaced by software updates.
"""


def _ensure_client_readme() -> None:
    if os.path.isfile(CLIENT_README_PATH):
        return
    with open(CLIENT_README_PATH, "w", encoding="utf-8") as handle:
        handle.write(CLIENT_README_TEXT)


_ensure_client_readme()
