import json
import os
import ssl
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from config.dev import is_dev_mode
from config.settings import (
    APP_VERSION,
    BASE_DIR,
    LICENSE_BLOCK_MESSAGE,
    LICENSE_FETCH_TIMEOUT_SECONDS,
    LICENSE_JSON_PATH,
    LICENSE_JSON_URL,
    LOCAL_DATA_DIR,
)
from core.session_service import (
    ACCOUNT_TYPE_ADMIN,
    ACCOUNT_TYPE_COMPANY,
    AppSession,
)

# One remote check per process / shop (startup-only semantics).
_remote_status_cache: dict[str, "LicenseStatus"] = {}


@dataclass(frozen=True)
class AuthResult:
    session: AppSession | None = None
    error_message: str | None = None


@dataclass(frozen=True)
class LicenseStatus:
    shop_id: str
    display_name: str
    account_type: str
    app_enabled: bool
    updates_enabled: bool
    latest_version: str
    message: str
    show_message: bool
    fetch_error: str | None = None
    checked_remote: bool = False

    @property
    def is_admin(self) -> bool:
        return self.account_type == ACCOUNT_TYPE_ADMIN

    @property
    def is_company(self) -> bool:
        return self.account_type == ACCOUNT_TYPE_COMPANY

    @property
    def is_accessible(self) -> bool:
        return self.app_enabled

    @property
    def block_message(self) -> str | None:
        if not self.app_enabled:
            return LICENSE_BLOCK_MESSAGE
        if self.show_message and self.message.strip():
            return self.message.strip()
        return None

    @property
    def update_available(self) -> bool:
        return False


@dataclass(frozen=True)
class ShopSummary:
    shop_id: str
    display_name: str
    account_type: str
    username: str
    app_enabled: bool
    updates_enabled: bool


def _license_json_paths() -> list[str]:
    return [
        os.path.join(LOCAL_DATA_DIR, "license.json"),
        LICENSE_JSON_PATH,
        os.path.join(BASE_DIR, "license.json"),
    ]


def _load_local_license_json() -> dict[str, Any] | None:
    for path in _license_json_paths():
        if not os.path.isfile(path):
            continue
        with open(path, encoding="utf-8") as handle:
            data = json.loads(handle.read().lstrip("\ufeff"))
        if not isinstance(data, dict):
            raise ValueError("License JSON root must be an object.")
        return data
    return None


def _fetch_license_json() -> dict[str, Any]:
    data = _load_local_license_json()
    if data is None:
        raise FileNotFoundError(
            "No accounts file found. Place license.json in your local_data folder."
        )
    return data


def _open_url(request: urllib.request.Request, *, verify_ssl: bool = True):
    if verify_ssl:
        return urllib.request.urlopen(request, timeout=LICENSE_FETCH_TIMEOUT_SECONDS)
    context = ssl._create_unverified_context()
    return urllib.request.urlopen(
        request, timeout=LICENSE_FETCH_TIMEOUT_SECONDS, context=context
    )


def _download_remote_license_json(url: str = LICENSE_JSON_URL) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": f"jewelry-inventory/{APP_VERSION}"},
    )
    try:
        with _open_url(request, verify_ssl=True) as response:
            raw = response.read().decode("utf-8", errors="replace")
    except Exception:
        with _open_url(request, verify_ssl=False) as response:
            raw = response.read().decode("utf-8", errors="replace")
    data = json.loads(raw.lstrip("\ufeff"))
    if not isinstance(data, dict):
        raise ValueError("License JSON root must be an object.")
    return data


def _parse_account_type(entry: dict[str, Any]) -> str:
    account_type = str(entry.get("account_type", "") or ACCOUNT_TYPE_COMPANY).strip().lower()
    if account_type == ACCOUNT_TYPE_ADMIN:
        return ACCOUNT_TYPE_ADMIN
    return ACCOUNT_TYPE_COMPANY


def _shops(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    for key in ("shops", "apps"):
        raw = data.get(key)
        if isinstance(raw, dict):
            return {name: value for name, value in raw.items() if isinstance(value, dict)}
    return {}


def _shop_entry(data: dict[str, Any], shop_id: str) -> dict[str, Any] | None:
    shops = _shops(data)
    entry = shops.get(shop_id)
    return entry if isinstance(entry, dict) else None


def _latest_version(data: dict[str, Any]) -> str:
    return str(data.get("latest_version", "") or "")


def authenticate(username: str, password: str) -> AuthResult:
    username = username.strip()
    password = password.strip()
    if not username or not password:
        return AuthResult(error_message="Enter a username and password.")

    try:
        data = _fetch_license_json()
    except FileNotFoundError as exc:
        return AuthResult(error_message=str(exc))
    except (json.JSONDecodeError, ValueError) as exc:
        return AuthResult(error_message=f"Accounts file is invalid: {exc}")

    shops = _shops(data)
    if not shops:
        return AuthResult(error_message="Accounts file has no shop accounts configured.")

    for shop_id, entry in shops.items():
        if str(entry.get("username", "")) == username and str(entry.get("password", "")) == password:
            display_name = str(entry.get("display_name", "") or shop_id)
            return AuthResult(
                session=AppSession(
                    shop_id=shop_id,
                    display_name=display_name,
                    account_type=_parse_account_type(entry),
                )
            )

    return AuthResult(error_message="Invalid username or password.")


def fetch_license_status(
    shop_id: str,
    display_name: str = "",
    account_type: str = ACCOUNT_TYPE_COMPANY,
) -> LicenseStatus:
    """Remote kill-switch check. Cached for the process lifetime (startup-only).

    No internet / fetch failure → fail open (app stays usable).
    Remote app_enabled=false → blocked with LICENSE_BLOCK_MESSAGE.
    """
    cached = _remote_status_cache.get(shop_id)
    if cached is not None:
        return cached

    if is_dev_mode():
        status = LicenseStatus(
            shop_id=shop_id,
            display_name=display_name or shop_id,
            account_type=account_type,
            app_enabled=True,
            updates_enabled=False,
            latest_version=APP_VERSION,
            message="",
            show_message=False,
            checked_remote=False,
        )
        _remote_status_cache[shop_id] = status
        return status

    try:
        data = _download_remote_license_json()
    except Exception as exc:
        status = LicenseStatus(
            shop_id=shop_id,
            display_name=display_name or shop_id,
            account_type=account_type,
            app_enabled=True,
            updates_enabled=False,
            latest_version=APP_VERSION,
            message="",
            show_message=False,
            fetch_error=str(exc),
            checked_remote=False,
        )
        _remote_status_cache[shop_id] = status
        return status

    entry = _shop_entry(data, shop_id)
    if entry is None:
        # Unknown shop on remote file — fail open so a local-only test shop still works.
        status = LicenseStatus(
            shop_id=shop_id,
            display_name=display_name or shop_id,
            account_type=account_type,
            app_enabled=True,
            updates_enabled=False,
            latest_version=_latest_version(data) or APP_VERSION,
            message="",
            show_message=False,
            fetch_error="Shop not found on license server",
            checked_remote=True,
        )
        _remote_status_cache[shop_id] = status
        return status

    remote_display = str(entry.get("display_name", "") or display_name or shop_id)
    remote_type = _parse_account_type(entry)
    status = LicenseStatus(
        shop_id=shop_id,
        display_name=remote_display,
        account_type=remote_type,
        app_enabled=bool(entry.get("app_enabled", False)),
        updates_enabled=bool(entry.get("updates_enabled", False)),
        latest_version=_latest_version(data) or APP_VERSION,
        message=str(entry.get("message", "") or ""),
        show_message=bool(entry.get("show_message", False)),
        checked_remote=True,
    )
    _remote_status_cache[shop_id] = status
    return status


def clear_license_status_cache() -> None:
    _remote_status_cache.clear()


def list_shop_summaries() -> list[ShopSummary]:
    try:
        data = _fetch_license_json()
    except (FileNotFoundError, json.JSONDecodeError, ValueError):
        return []

    summaries: list[ShopSummary] = []
    for shop_id, entry in sorted(_shops(data).items()):
        summaries.append(
            ShopSummary(
                shop_id=shop_id,
                display_name=str(entry.get("display_name", "") or shop_id),
                account_type=_parse_account_type(entry),
                username=str(entry.get("username", "") or ""),
                app_enabled=bool(entry.get("app_enabled", False)),
                updates_enabled=bool(entry.get("updates_enabled", False)),
            )
        )
    return summaries


def set_shop_flags(shop_id: str, *, app_enabled: bool, updates_enabled: bool) -> None:
    data = _fetch_license_json()
    shops = _shops(data)
    if shop_id not in shops:
        raise KeyError(f"Unknown shop: {shop_id}")
    shops[shop_id]["app_enabled"] = bool(app_enabled)
    shops[shop_id]["updates_enabled"] = bool(updates_enabled)
    _write_local_license_json(data)
    clear_license_status_cache()


def set_latest_version(version: str) -> str:
    cleaned = version.strip()
    data = _fetch_license_json()
    data["latest_version"] = cleaned
    _write_local_license_json(data)
    return cleaned


def _write_local_license_json(data: dict[str, Any]) -> None:
    path = LICENSE_JSON_PATH
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2)
        handle.write("\n")
