"""Launch the company app in local development mode."""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from config.dev import clear_dev_settings_cache, dev_session, is_dev_mode
from config.settings import APP_PORT, BASE_DIR, DEV_SETTINGS_PATH, LOCAL_FILES_DIR
from core.session_service import clear_session, load_session, save_session

DEV_SETTINGS_EXAMPLE = Path(LOCAL_FILES_DIR) / "dev_settings.example.py"
MAIN_SCRIPT = Path(BASE_DIR) / "main.py"
DEV_SHOP_ID = "local-dev"

DEV_SETTINGS_TEMPLATE = '''"""Local development settings — enabled from the admin dashboard."""

DEV_MODE = True
DEV_ACCOUNT_TYPE = "company"
DEV_SHOP_ID = "local-dev"
DEV_DISPLAY_NAME = "Local Development"
'''


def company_app_url() -> str:
    return f"http://127.0.0.1:{APP_PORT}"


def enable_local_development() -> None:
    Path(LOCAL_FILES_DIR).mkdir(parents=True, exist_ok=True)
    Path(DEV_SETTINGS_PATH).write_text(DEV_SETTINGS_TEMPLATE, encoding="utf-8")
    clear_dev_settings_cache()
    if not is_dev_mode():
        raise RuntimeError("Could not enable development mode.")
    save_session(dev_session())


def clear_local_sign_in() -> None:
    """Clear saved session and disable dev mode for a fresh company-app login."""
    disable_local_development()
    clear_session()


def disable_local_development() -> None:
    Path(LOCAL_FILES_DIR).mkdir(parents=True, exist_ok=True)
    if DEV_SETTINGS_EXAMPLE.exists():
        content = DEV_SETTINGS_EXAMPLE.read_text(encoding="utf-8")
    else:
        content = (
            'DEV_MODE = False\nDEV_ACCOUNT_TYPE = "company"\n'
            'DEV_SHOP_ID = "local-dev"\nDEV_DISPLAY_NAME = "Local Development"\n'
        )
    Path(DEV_SETTINGS_PATH).write_text(content, encoding="utf-8")
    clear_dev_settings_cache()
    session = load_session()
    if session is not None and session.shop_id == DEV_SHOP_ID:
        clear_session()


def _is_main_app_running() -> bool:
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.3)
        return sock.connect_ex(("127.0.0.1", APP_PORT)) == 0


def _pids_listening_on_port(port: int) -> list[int]:
    own_pid = os.getpid()
    pids: list[int] = []

    if sys.platform == "win32":
        result = subprocess.run(
            ["netstat", "-ano"],
            capture_output=True,
            text=True,
            check=False,
        )
        needle = f":{port}"
        for line in result.stdout.splitlines():
            if needle not in line or "LISTENING" not in line:
                continue
            token = line.split()[-1]
            if token.isdigit():
                pid = int(token)
                if pid != own_pid:
                    pids.append(pid)
        return list(dict.fromkeys(pids))

    import signal

    result = subprocess.run(
        ["lsof", "-ti", f":{port}"],
        capture_output=True,
        text=True,
        check=False,
    )
    for token in result.stdout.split():
        if token.strip().isdigit():
            pid = int(token.strip())
            if pid != own_pid:
                pids.append(pid)
    return list(dict.fromkeys(pids))


def _stop_company_app() -> bool:
    """Try to free the app port. Returns True if the port is free afterwards."""
    if not _is_main_app_running():
        return True

    for _ in range(3):
        for pid in _pids_listening_on_port(APP_PORT):
            if sys.platform == "win32":
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(pid)],
                    check=False,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            else:
                import signal

                os.kill(pid, signal.SIGTERM)
        time.sleep(0.75)
        if not _is_main_app_running():
            return True

    return not _is_main_app_running()


def start_company_app() -> tuple[str, str]:
    """Start or reuse the company app. Returns (url, status_message)."""
    enable_local_development()

    if _is_main_app_running():
        stopped = _stop_company_app()
        if not stopped and _is_main_app_running():
            return (
                company_app_url(),
                f"Company app is already running on port {APP_PORT}.",
            )

    if not _is_main_app_running():
        env = os.environ.copy()
        env["JEWELRY_NO_BROWSER"] = "1"
        popen_kwargs: dict = {
            "cwd": str(BASE_DIR),
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
            "env": env,
        }
        if sys.platform == "win32":
            popen_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
        subprocess.Popen([sys.executable, str(MAIN_SCRIPT)], **popen_kwargs)
        for _ in range(40):
            if _is_main_app_running():
                break
            time.sleep(0.25)
        else:
            raise RuntimeError(
                f"Company app did not start on port {APP_PORT}. "
                "Run `python main.py` from app/ in a terminal to see startup errors."
            )
        return company_app_url(), f"Company app started at {company_app_url()}."

    return company_app_url(), f"Company app restarted at {company_app_url()}."
