from datetime import date, datetime

from nicegui import app, run, ui

from config.item_options import ITEM_TYPES
from config.settings import APP_VERSION
from core.flow_service import (
    format_net_items,
    item_label,
    item_margin_pct,
    item_profit,
    load_flow_data,
    period_bounds,
)
from core.session_service import load_session
from ui.app_nav import render_app_nav
from ui.dev_banner import render_dev_banner
from ui.flow_longest_dialog import open_longest_in_stock_dialog


def _format_euro(amount: float) -> str:
    return f"€ {int(round(amount)):,}"


def _format_display_date(value: date) -> str:
    return value.strftime("%d/%m/%Y")


def _format_item_date(value: str) -> str:
    try:
        return datetime.strptime(value[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        return value[:10]


def _parse_ui_date(value) -> date | None:
    if value is None or value == "":
        return None
    if isinstance(value, date):
        return value
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def _format_margin(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.0f}%"


def _format_margin_comparison(metric: dict) -> str:
    diff = metric["diff"]
    if diff is None:
        return "— vs previous"
    sign = "+" if diff > 0 else ""
    return f"{sign}{diff:.0f} pts vs previous"


def _format_comparison(metric: dict, *, currency: bool = False) -> str:
    diff = metric["diff"]
    percent = metric["percent"]
    if currency:
        diff_text = _format_euro(abs(diff))
    else:
        diff_text = str(abs(int(diff)))
    if diff > 0:
        sign = "+"
    elif diff < 0:
        sign = "-"
    else:
        sign = ""
    if percent is None:
        percent_text = "—"
    else:
        percent_text = f"{percent:+.0f}%"
    return f"{sign}{diff_text} vs previous ({percent_text})"


def _flow_chart_options(chart: dict) -> dict:
    return {
        "tooltip": {"trigger": "axis"},
        "legend": {
            "data": ["Items in", "Items out", "Profit"],
            "bottom": 0,
        },
        "grid": {"left": "3%", "right": "4%", "top": "8%", "bottom": "14%", "containLabel": True},
        "xAxis": {"type": "category", "data": chart["labels"]},
        "yAxis": [
            {"type": "value", "name": "Items", "minInterval": 1},
            {"type": "value", "name": "Profit (€)"},
        ],
        "series": [
            {"name": "Items in", "type": "bar", "data": chart["added_counts"]},
            {"name": "Items out", "type": "bar", "data": chart["sold_counts"]},
            {
                "name": "Profit",
                "type": "line",
                "yAxisIndex": 1,
                "data": chart["profit_totals"],
                "smooth": True,
            },
        ],
    }


def _profit_chart_zoom(labels: list[str]) -> list[dict]:
    if len(labels) <= 31:
        return []
    return [{"type": "inside"}, {"type": "slider", "bottom": 0}]


def _daily_profit_chart_options(profit_charts: dict) -> dict:
    labels = profit_charts["labels"]
    zoom = _profit_chart_zoom(labels)
    return {
        "title": {"text": "Profit by day", "left": "center"},
        "tooltip": {"trigger": "axis"},
        "grid": {
            "left": "3%",
            "right": "4%",
            "top": "15%",
            "bottom": "18%" if zoom else "8%",
            "containLabel": True,
        },
        "xAxis": {"type": "category", "data": labels},
        "yAxis": {"type": "value", "name": "Profit (€)"},
        "dataZoom": zoom,
        "series": [{"name": "Profit", "type": "bar", "data": profit_charts["daily_profit"]}],
    }


def _cumulative_profit_chart_options(profit_charts: dict) -> dict:
    labels = profit_charts["labels"]
    zoom = _profit_chart_zoom(labels)
    return {
        "title": {"text": "Cumulative profit", "left": "center"},
        "tooltip": {"trigger": "axis"},
        "grid": {
            "left": "3%",
            "right": "4%",
            "top": "15%",
            "bottom": "18%" if zoom else "8%",
            "containLabel": True,
        },
        "xAxis": {"type": "category", "data": labels},
        "yAxis": {"type": "value", "name": "Profit (€)"},
        "dataZoom": zoom,
        "series": [
            {
                "name": "Cumulative profit",
                "type": "line",
                "data": profit_charts["cumulative_profit"],
                "smooth": True,
            }
        ],
    }


def _margin_pie_options(breakdown: dict) -> dict | None:
    entries = [
        {
            "name": f"{name} ({breakdown['margin_pct'][name]:.0f}%)",
            "value": round(breakdown["margin_pct"][name], 1),
        }
        for name in sorted(breakdown["margin_pct"])
        if breakdown["revenue"].get(name, 0) > 0
    ]
    if not entries:
        return None
    return {
        "title": {"text": "Margin by type", "left": "center"},
        "tooltip": {"trigger": "item", "formatter": "{b}: {c}% avg margin"},
        "series": [
            {
                "type": "pie",
                "radius": ["35%", "65%"],
                "data": entries,
            }
        ],
    }


def _pie_chart_options(title: str, data: dict[str, float]) -> dict | None:
    entries = [
        {"name": name, "value": round(value)}
        for name, value in sorted(data.items())
        if value > 0
    ]
    if not entries:
        return None
    return {
        "title": {"text": title, "left": "center"},
        "tooltip": {"trigger": "item"},
        "series": [
            {
                "type": "pie",
                "radius": ["35%", "65%"],
                "data": entries,
            }
        ],
    }


def _granularity_label(granularity: str) -> str:
    labels = {"day": "daily", "week": "weekly", "month": "monthly"}
    return labels.get(granularity, granularity)


def _sync_period_inputs(state: dict, custom_start_input, custom_end_input) -> None:
    custom_start = _parse_ui_date(custom_start_input.value)
    custom_end = _parse_ui_date(custom_end_input.value)
    if state["period_mode"] == "custom":
        if custom_start is None or custom_end is None:
            raise ValueError("Choose a valid start and end date")
        state["custom_start"] = custom_start
        state["custom_end"] = custom_end


def _flow_query_kwargs(
    state: dict,
    *,
    custom_start_input,
    custom_end_input,
    month_input,
    year_select,
) -> dict:
    _sync_period_inputs(state, custom_start_input, custom_end_input)
    return {
        "mode": state["period_mode"],
        "item_type": state["item_type"],
        "custom_start": state["custom_start"] if state["period_mode"] == "custom" else None,
        "custom_end": state["custom_end"] if state["period_mode"] == "custom" else None,
        "selected_month": month_input.value if state["period_mode"] == "month" else None,
        "selected_year": int(year_select.value) if state["period_mode"] == "year" else None,
    }


_FLOW_DETAIL_KEY = "flow_more_detail"


def show_flow():
    session = load_session()
    current_year = date.today().year
    state = {
        "period_mode": "month",
        "item_type": "All",
        "custom_start": date.today().replace(day=1),
        "custom_end": date.today(),
        "selected_month": date.today().strftime("%Y-%m"),
        "selected_year": current_year,
        "advanced": bool(app.storage.browser.get(_FLOW_DETAIL_KEY, False)),
    }

    render_dev_banner()

    with ui.row().classes("w-full items-center justify-between mb-2 gap-4"):
        with ui.row().classes("items-center gap-4 grow min-w-0"):
            shop_name = session.display_name if session else "Inventory"
            ui.label(shop_name).classes("text-2xl font-bold truncate")
        ui.link("Sign out", "/logout").classes("text-sm text-gray-500 shrink-0")

    render_app_nav("flow")
    ui.label(f"Flow · v{APP_VERSION}").classes("text-lg text-gray-600 mb-1")
    ui.label("Consignment items are excluded from all totals.").classes(
        "text-sm text-gray-500 mb-4"
    )

    period_options = {
        "7days": "Last 7 days",
        "month": "Month",
        "year": "Year",
        "custom": "Select period",
    }

    with ui.row().classes("w-full gap-4 flex-wrap items-end mb-4"):
        period_select = ui.select(
            period_options,
            label="Period",
            value=state["period_mode"],
        ).classes("min-w-[12rem]").props("dense outlined")

        type_select = ui.select(
            {"All": "All types", **{item_type: item_type for item_type in ITEM_TYPES}},
            label="Type",
            value=state["item_type"],
        ).classes("min-w-[12rem]").props("dense outlined")

        export_btn = ui.button("Export to Excel").props("no-caps outline")
        pdf_btn = ui.button("Chart to PDF").props("no-caps outline")

    with ui.row().classes("w-full items-center justify-between mb-4"):
        with ui.row().classes("items-center gap-4"):
            detail_switch = ui.switch("More detail", value=state["advanced"]).props("dense")
            refresh_btn = ui.button("Refresh").props("no-caps outline dense")

            def open_longest_dialog() -> None:
                open_longest_in_stock_dialog(item_type=state["item_type"])

            ui.button("Longest in stock", on_click=open_longest_dialog).props("no-caps outline dense")
        detail_hint = ui.label(
            "Overview of how the business is doing"
            if not state["advanced"]
            else "Full charts, comparisons, and item lists"
        ).classes("text-sm text-gray-500")

    custom_period_row = ui.row().classes("w-full gap-4 flex-wrap items-end mb-4")

    with custom_period_row:
        custom_start_input = ui.input(
            "From",
            value=state["custom_start"].isoformat(),
        ).classes("w-40").props("dense outlined type=date")
        custom_end_input = ui.input(
            "To",
            value=state["custom_end"].isoformat(),
        ).classes("w-40").props("dense outlined type=date")

    month_period_row = ui.row().classes("w-full gap-4 flex-wrap items-end mb-4")
    with month_period_row:
        month_input = ui.input(
            "Month",
            value=state["selected_month"],
        ).classes("w-44").props("dense outlined type=month")

    year_period_row = ui.row().classes("w-full gap-4 flex-wrap items-end mb-4")
    with year_period_row:
        year_select = ui.select(
            {year: str(year) for year in range(2020, current_year + 1)},
            label="Year",
            value=state["selected_year"],
        ).classes("w-32").props("dense outlined")

    def update_period_input_visibility() -> None:
        custom_period_row.set_visibility(state["period_mode"] == "custom")
        month_period_row.set_visibility(state["period_mode"] == "month")
        year_period_row.set_visibility(state["period_mode"] == "year")

    update_period_input_visibility()

    def current_flow_data() -> dict:
        query = _flow_query_kwargs(
            state,
            custom_start_input=custom_start_input,
            custom_end_input=custom_end_input,
            month_input=month_input,
            year_select=year_select,
        )
        return load_flow_data(**query)

    @ui.refreshable
    def flow_content() -> None:
        try:
            flow = current_flow_data()
        except ValueError as exc:
            ui.label(str(exc)).classes("text-red-600")
            return

        advanced = state["advanced"]
        summary = flow["summary"]
        comparison = flow["comparison"]
        profit = summary["sold_profit_total"]
        cash = summary["cash"]
        profit_class = "text-green-600" if profit >= 0 else "text-red-600"
        net_cash_class = "text-green-600" if cash["net_cash"] >= 0 else "text-red-600"
        net_value = summary["net_items"]
        net_color = "text-green-700" if net_value >= 0 else "text-red-700"

        ui.label(
            f"{_format_display_date(flow['period_start'])} – "
            f"{_format_display_date(flow['period_end'])}"
        ).classes("text-sm text-gray-600 mb-2")

        if advanced:
            ui.label(
                f"Compared to {_format_display_date(flow['previous_period_start'])} – "
                f"{_format_display_date(flow['previous_period_end'])}"
            ).classes("text-sm text-gray-600 mb-2")

        net_text = format_net_items(summary["added_count"], summary["sold_count"])
        ui.label(
            f"Net items: {net_text} "
            f"({summary['added_count']} added, {summary['sold_count']} sold)"
        ).classes(f"text-base font-medium mb-4 {net_color}")

        with ui.row().classes("w-full gap-4 flex-wrap mb-6"):
            if not advanced:
                with ui.card().classes("p-5 w-full"):
                    ui.label("Overview").classes("text-lg font-semibold mb-3")
                    with ui.row().classes("gap-8 flex-wrap"):
                        with ui.column().classes("gap-1"):
                            ui.label("Profit").classes("text-sm text-gray-600")
                            ui.label(_format_euro(profit)).classes(
                                f"text-2xl font-bold {profit_class}"
                            )
                        with ui.column().classes("gap-1"):
                            ui.label("Revenue").classes("text-sm text-gray-600")
                            ui.label(_format_euro(summary["sold_sell_total"])).classes(
                                "text-2xl font-bold"
                            )
                        with ui.column().classes("gap-1"):
                            ui.label("Margin").classes("text-sm text-gray-600")
                            ui.label(_format_margin(summary["sold_margin_pct"])).classes(
                                "text-2xl font-bold"
                            )
                        with ui.column().classes("gap-1"):
                            ui.label("Net cash").classes("text-sm text-gray-600")
                            ui.label(_format_euro(cash["net_cash"])).classes(
                                f"text-2xl font-bold {net_cash_class}"
                            )
                        with ui.column().classes("gap-1"):
                            ui.label("Movement").classes("text-sm text-gray-600")
                            ui.label(
                                f"{summary['added_count']} in · {summary['sold_count']} out"
                            ).classes("text-2xl font-bold")
            else:
                with ui.card().classes("p-4 grow min-w-[16rem]"):
                    ui.label("Added").classes("text-lg font-semibold mb-2")
                    ui.label(f"Items: {summary['added_count']}")
                    ui.label(
                        _format_comparison(comparison["added_count"])
                    ).classes("text-sm text-gray-600")
                    ui.label(f"Purchase total: {_format_euro(summary['added_purchase_total'])}")
                    ui.label(
                        _format_comparison(comparison["added_purchase"], currency=True)
                    ).classes("text-sm text-gray-600")
                    ui.label(f"Sell value: {_format_euro(summary['added_sell_total'])}")
                    outcomes = summary["added_outcomes"]
                    if outcomes["total"] > 0:
                        ui.label(
                            f"Since added: {outcomes['sold']} sold · "
                            f"{outcomes['in_stock']} in stock · "
                            f"{outcomes['reserved']} reserved"
                        ).classes("text-sm text-gray-700 mt-1")

                with ui.card().classes("p-4 grow min-w-[16rem]"):
                    ui.label("Sold").classes("text-lg font-semibold mb-2")
                    ui.label(f"Items: {summary['sold_count']}")
                    ui.label(
                        _format_comparison(comparison["sold_count"])
                    ).classes("text-sm text-gray-600")
                    ui.label(f"Revenue: {_format_euro(summary['sold_sell_total'])}")
                    ui.label(
                        _format_comparison(comparison["sold_revenue"], currency=True)
                    ).classes("text-sm text-gray-600")
                    ui.label(f"Profit: {_format_euro(profit)}").classes(profit_class)
                    ui.label(
                        _format_comparison(comparison["sold_profit"], currency=True)
                    ).classes("text-sm text-gray-600")
                    ui.label(f"Margin: {_format_margin(summary['sold_margin_pct'])}").classes(
                        "text-sm mt-1"
                    )
                    ui.label(
                        _format_margin_comparison(comparison["sold_margin_pct"])
                    ).classes("text-sm text-gray-600")
                    avg_days = summary["average_days_to_sell"]
                    if avg_days is None:
                        ui.label("Avg. time to sell: —").classes("text-sm mt-1")
                    else:
                        ui.label(f"Avg. time to sell: {avg_days:.0f} days").classes(
                            "text-sm mt-1"
                        )

                net_cash = cash["net_cash"]
                with ui.card().classes("p-4 grow min-w-[16rem]"):
                    ui.label("Cash flow").classes("text-lg font-semibold mb-2")
                    ui.label(f"Cash in (sales): {_format_euro(cash['cash_in'])}")
                    ui.label(
                        _format_comparison(comparison["sold_revenue"], currency=True)
                    ).classes("text-sm text-gray-600")
                    ui.label(f"Cash out (purchases): {_format_euro(cash['cash_out'])}")
                    ui.label(
                        _format_comparison(comparison["added_purchase"], currency=True)
                    ).classes("text-sm text-gray-600")
                    ui.label(f"Net cash: {_format_euro(net_cash)}").classes(net_cash_class)
                    ui.label(
                        _format_comparison(comparison["net_cash"], currency=True)
                    ).classes("text-sm text-gray-600")

        chart = flow["chart"]
        with ui.column().classes("w-full mb-6"):
            chart_title = (
                f"Flow chart ({_granularity_label(chart['granularity'])})"
                if advanced
                else "Activity"
            )
            ui.label(chart_title).classes("text-lg font-semibold mb-2")
            ui.echart(_flow_chart_options(chart)).classes("w-full h-80")

        if advanced:
            profit_charts = flow["profit_charts"]
            with ui.column().classes("w-full mb-6"):
                with ui.grid(columns=2).classes("w-full gap-4"):
                    ui.echart(_daily_profit_chart_options(profit_charts)).classes(
                        "w-full h-72"
                    )
                    ui.echart(_cumulative_profit_chart_options(profit_charts)).classes(
                        "w-full h-72"
                    )

            breakdown = flow["type_breakdown"]
            revenue_options = _pie_chart_options("Revenue by type", breakdown["revenue"])
            profit_options = _pie_chart_options("Profit by type", breakdown["profit"])
            margin_options = _margin_pie_options(breakdown)
            with ui.column().classes("w-full mb-6"):
                ui.label("Breakdown by type").classes("text-lg font-semibold mb-2")
                if revenue_options or profit_options or margin_options:
                    with ui.grid(columns=3).classes("w-full gap-4"):
                        if revenue_options:
                            ui.echart(revenue_options).classes("w-full h-72")
                        if profit_options:
                            ui.echart(profit_options).classes("w-full h-72")
                        if margin_options:
                            ui.echart(margin_options).classes("w-full h-72")
                else:
                    ui.label("No sold items to break down by type.").classes(
                        "text-gray-500"
                    )

            with ui.row().classes("w-full gap-6 flex-wrap items-start"):
                with ui.column().classes("grow min-w-[20rem] gap-2"):
                    ui.label("Items in").classes("text-lg font-semibold")
                    if not flow["added_items"]:
                        ui.label("No items added in this period.").classes("text-gray-500")
                    else:
                        for item in flow["added_items"]:
                            with ui.card().classes("p-3 w-full"):
                                ui.label(_format_item_date(item["added_date"])).classes(
                                    "text-xs text-gray-500"
                                )
                                ui.label(f"#{item['id']} · {item_label(item)}").classes(
                                    "font-medium"
                                )
                                ui.label(
                                    f"Purchase: {_format_euro(float(item['purchase_price'] or 0))} · "
                                    f"Sell: {_format_euro(float(item['sell_price'] or 0))}"
                                ).classes("text-sm text-gray-700")

                with ui.column().classes("grow min-w-[20rem] gap-2"):
                    ui.label("Items out").classes("text-lg font-semibold")
                    if not flow["sold_items"]:
                        ui.label("No items sold in this period.").classes("text-gray-500")
                    else:
                        for item in flow["sold_items"]:
                            item_profit_value = item_profit(item)
                            margin = item_margin_pct(item)
                            margin_text = (
                                f" · Margin: {_format_margin(margin)}"
                                if margin is not None
                                else ""
                            )
                            with ui.card().classes("p-3 w-full"):
                                ui.label(_format_item_date(item["sold_date"])).classes(
                                    "text-xs text-gray-500"
                                )
                                ui.label(f"#{item['id']} · {item_label(item)}").classes(
                                    "font-medium"
                                )
                                ui.label(
                                    f"Sold: {_format_euro(float(item['sell_price'] or 0))} · "
                                    f"Profit: {_format_euro(item_profit_value)}{margin_text}"
                                ).classes(
                                    "text-sm text-green-600"
                                    if item_profit_value >= 0
                                    else "text-sm text-red-600"
                                )

    async def apply_filters() -> None:
        state["period_mode"] = period_select.value or "month"
        state["item_type"] = type_select.value or "All"
        if state["period_mode"] == "month":
            state["selected_month"] = month_input.value or state["selected_month"]
        if state["period_mode"] == "year":
            state["selected_year"] = int(year_select.value or state["selected_year"])
        update_period_input_visibility()
        await flow_content.refresh()

    async def on_detail_toggle(event) -> None:
        state["advanced"] = bool(event.value)
        app.storage.browser[_FLOW_DETAIL_KEY] = state["advanced"]
        detail_hint.text = (
            "Full charts, comparisons, and item lists"
            if state["advanced"]
            else "Overview of how the business is doing"
        )
        await apply_filters()

    detail_switch.on_value_change(on_detail_toggle)

    async def export_flow() -> None:
        if export_btn.is_deleted:
            return
        export_btn.disable()
        export_btn.text = "Exporting..."
        try:
            from core.export_service import build_flow_excel, flow_export_filename

            query = _flow_query_kwargs(
                state,
                custom_start_input=custom_start_input,
                custom_end_input=custom_end_input,
                month_input=month_input,
                year_select=year_select,
            )
            period_start, period_end = period_bounds(
                query["mode"],
                custom_start=query["custom_start"],
                custom_end=query["custom_end"],
                selected_month=query["selected_month"],
                selected_year=query["selected_year"],
            )
            shop_name = session.display_name if session else None
            data = await run.cpu_bound(
                build_flow_excel,
                period_mode=query["mode"],
                item_type=query["item_type"],
                custom_start=query["custom_start"],
                custom_end=query["custom_end"],
                selected_month=query["selected_month"],
                selected_year=query["selected_year"],
                shop_name=shop_name,
            )
            ui.download(data, flow_export_filename(period_start, period_end))
            ui.notify("Flow export downloaded", type="positive")
        except ValueError as exc:
            ui.notify(str(exc), type="negative")
        except Exception as exc:
            ui.notify(f"Export failed: {exc}", type="negative")
        finally:
            if not export_btn.is_deleted:
                export_btn.text = "Export to Excel"
                export_btn.enable()

    async def export_pdf() -> None:
        if pdf_btn.is_deleted:
            return
        pdf_btn.disable()
        pdf_btn.text = "Exporting..."
        try:
            from core.flow_pdf_service import build_flow_pdf, flow_pdf_filename

            query = _flow_query_kwargs(
                state,
                custom_start_input=custom_start_input,
                custom_end_input=custom_end_input,
                month_input=month_input,
                year_select=year_select,
            )
            period_start, period_end = period_bounds(
                query["mode"],
                custom_start=query["custom_start"],
                custom_end=query["custom_end"],
                selected_month=query["selected_month"],
                selected_year=query["selected_year"],
            )
            shop_name = session.display_name if session else None
            data = await run.cpu_bound(
                build_flow_pdf,
                period_mode=query["mode"],
                item_type=query["item_type"],
                custom_start=query["custom_start"],
                custom_end=query["custom_end"],
                selected_month=query["selected_month"],
                selected_year=query["selected_year"],
                shop_name=shop_name,
            )
            ui.download(data, flow_pdf_filename(period_start, period_end))
            ui.notify("PDF report downloaded", type="positive")
        except ValueError as exc:
            ui.notify(str(exc), type="negative")
        except Exception as exc:
            ui.notify(f"PDF export failed: {exc}", type="negative")
        finally:
            if not pdf_btn.is_deleted:
                pdf_btn.text = "Chart to PDF"
                pdf_btn.enable()

    export_btn.on("click", export_flow)
    pdf_btn.on("click", export_pdf)
    refresh_btn.on("click", apply_filters)
    period_select.on("update:model-value", apply_filters)
    type_select.on("update:model-value", apply_filters)
    custom_start_input.on("update:model-value", apply_filters)
    custom_end_input.on("update:model-value", apply_filters)
    month_input.on("update:model-value", apply_filters)
    year_select.on("update:model-value", apply_filters)

    flow_content()

    ui.context.client.on_connect(lambda: flow_content.refresh())


def register_flow_page() -> None:
    @ui.page("/flow")
    def flow_page() -> None:
        from config.dev import is_dev_mode

        if load_session() is None and not is_dev_mode():
            ui.navigate.to("/login")
            return
        show_flow()
