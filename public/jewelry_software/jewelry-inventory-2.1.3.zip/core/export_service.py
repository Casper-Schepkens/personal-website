"""Export inventory data to Excel."""

from __future__ import annotations

from datetime import date, datetime
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from core.flow_service import format_net_items, item_label, item_margin_pct, item_profit
from core.image_service import has_image
from core.inventory_service import load_all_items_for_export

EXPORT_COLUMNS = [
    ("id", "ID"),
    ("item_type", "Item type"),
    ("metal", "Metal"),
    ("stone", "Stone"),
    ("carat", "Carat"),
    ("sidestone", "Sidestone"),
    ("sidestone_carat", "Sidestone carat"),
    ("weight", "Weight (g)"),
    ("purchase_price", "Purchase price"),
    ("sell_price", "Sell price"),
    ("profit", "Profit"),
    ("stock", "Stock"),
    ("certificate", "Certificate"),
    ("consignment", "Consignment"),
    ("added_date", "Added date"),
    ("sold_date", "Sold date"),
    ("has_photo", "Has photo"),
]


def _row_values(item) -> list:
    purchase = float(item["purchase_price"] or 0)
    sell = float(item["sell_price"] or 0)
    return [
        item["id"],
        item["item_type"],
        item["metal"],
        item["stone"],
        float(item["carat"] or 0),
        item["sidestone"],
        float(item["sidestone_carat"] or 0),
        float(item["weight"] or 0),
        purchase,
        sell,
        sell - purchase,
        item["stock"],
        item["certificate"],
        item["consignment"] or "no",
        item["added_date"] or "",
        item["sold_date"] or "",
        "yes" if has_image(item["id"]) else "no",
    ]


def build_inventory_excel(*, shop_name: str | None = None) -> bytes:
    items = load_all_items_for_export()
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Inventory"

    headers = [label for _, label in EXPORT_COLUMNS]
    sheet.append(headers)
    for cell in sheet[1]:
        cell.font = Font(bold=True)

    for item in items:
        sheet.append(_row_values(item))

    for index, (_, label) in enumerate(EXPORT_COLUMNS, start=1):
        column = get_column_letter(index)
        width = max(len(label) + 2, 12)
        sheet.column_dimensions[column].width = width

    info_sheet = workbook.create_sheet("Export info")
    info_sheet.append(["Exported at", datetime.now().strftime("%Y-%m-%d %H:%M")])
    info_sheet.append(["Shop", shop_name or ""])
    info_sheet.append(["Item count", len(items)])
    info_sheet.append(
        [
            "Note",
            "Consignment items excluded (consignment=yes or purchase price 0)",
        ]
    )

    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def inventory_export_filename() -> str:
    stamp = datetime.now().strftime("%Y%m%d")
    return f"jewelry_inventory_{stamp}.xlsx"


def _bold_header_row(sheet) -> None:
    for cell in sheet[1]:
        cell.font = Font(bold=True)


def _autosize_columns(sheet, headers: list[str]) -> None:
    for index, label in enumerate(headers, start=1):
        column = get_column_letter(index)
        width = max(len(label) + 2, 12)
        sheet.column_dimensions[column].width = width


def build_flow_excel(
    *,
    period_mode: str = "month",
    item_type: str = "All",
    custom_start: date | None = None,
    custom_end: date | None = None,
    selected_month: str | None = None,
    selected_year: int | None = None,
    shop_name: str | None = None,
) -> bytes:
    from core.flow_service import load_flow_data

    flow = load_flow_data(
        period_mode,
        item_type=item_type,
        custom_start=custom_start,
        custom_end=custom_end,
        selected_month=selected_month,
        selected_year=selected_year,
    )
    workbook = Workbook()

    summary_sheet = workbook.active
    summary_sheet.title = "Summary"
    summary = flow["summary"]
    period_start: date = flow["period_start"]
    period_end: date = flow["period_end"]
    summary_rows = [
        ["Exported at", datetime.now().strftime("%Y-%m-%d %H:%M")],
        ["Shop", shop_name or ""],
        ["Period mode", period_mode],
        ["Period start", period_start.isoformat()],
        ["Period end", period_end.isoformat()],
        ["Item type filter", item_type],
        [],
        ["Added items", summary["added_count"]],
        ["Added purchase total", summary["added_purchase_total"]],
        ["Added sell value", summary["added_sell_total"]],
        ["Sold items", summary["sold_count"]],
        ["Sold revenue", summary["sold_sell_total"]],
        ["Sold profit", summary["sold_profit_total"]],
        [
            "Sold margin %",
            round(summary["sold_margin_pct"], 1)
            if summary.get("sold_margin_pct") is not None
            else "",
        ],
        [
            "Net items",
            format_net_items(summary["added_count"], summary["sold_count"]),
        ],
        ["Cash in (sales)", summary["cash"]["cash_in"]],
        ["Cash out (purchases)", summary["cash"]["cash_out"]],
        ["Net cash", summary["cash"]["net_cash"]],
    ]
    outcomes = summary.get("added_outcomes") or {}
    if outcomes.get("total"):
        summary_rows.extend(
            [
                [],
                ["Added since - sold", outcomes.get("sold", 0)],
                ["Added since - in stock", outcomes.get("in_stock", 0)],
                ["Added since - reserved", outcomes.get("reserved", 0)],
            ]
        )
    avg_days = summary.get("average_days_to_sell")
    summary_rows.append(
        ["Average time to sell (days)", round(avg_days) if avg_days is not None else ""]
    )
    comparison = flow.get("comparison")
    if comparison:
        summary_rows.extend(
            [
                [],
                ["Vs previous - sold profit diff", comparison["sold_profit"]["diff"]],
                ["Vs previous - sold revenue diff", comparison["sold_revenue"]["diff"]],
                ["Vs previous - sold items diff", comparison["sold_count"]["diff"]],
                ["Vs previous - net cash diff", comparison["net_cash"]["diff"]],
            ]
        )
    summary_rows.append(
        ["Note", "Consignment items excluded (consignment=yes or purchase price 0)"]
    )
    for row in summary_rows:
        summary_sheet.append(row)

    added_sheet = workbook.create_sheet("Items in")
    added_headers = [
        "Date",
        "ID",
        "Description",
        "Item type",
        "Purchase price",
        "Sell price",
    ]
    added_sheet.append(added_headers)
    _bold_header_row(added_sheet)
    for item in flow["added_items"]:
        added_sheet.append(
            [
                item["added_date"] or "",
                item["id"],
                item_label(item),
                item["item_type"],
                float(item["purchase_price"] or 0),
                float(item["sell_price"] or 0),
            ]
        )
    _autosize_columns(added_sheet, added_headers)

    sold_sheet = workbook.create_sheet("Items out")
    sold_headers = [
        "Date",
        "ID",
        "Description",
        "Item type",
        "Sell price",
        "Profit",
        "Margin %",
    ]
    sold_sheet.append(sold_headers)
    _bold_header_row(sold_sheet)
    for item in flow["sold_items"]:
        margin = item_margin_pct(item)
        sold_sheet.append(
            [
                item["sold_date"] or "",
                item["id"],
                item_label(item),
                item["item_type"],
                float(item["sell_price"] or 0),
                item_profit(item),
                round(margin, 1) if margin is not None else "",
            ]
        )
    _autosize_columns(sold_sheet, sold_headers)

    chart = flow["chart"]
    chart_sheet = workbook.create_sheet("Chart data")
    chart_headers = ["Period", "Items in", "Items out", "Profit"]
    chart_sheet.append(chart_headers)
    _bold_header_row(chart_sheet)
    for index, label in enumerate(chart["labels"]):
        chart_sheet.append(
            [
                label,
                chart["added_counts"][index],
                chart["sold_counts"][index],
                chart["profit_totals"][index],
            ]
        )
    _autosize_columns(chart_sheet, chart_headers)

    buffer = BytesIO()
    workbook.save(buffer)
    return buffer.getvalue()


def flow_export_filename(period_start: date, period_end: date) -> str:
    start = period_start.strftime("%Y%m%d")
    end = period_end.strftime("%Y%m%d")
    return f"jewelry_flow_{start}_{end}.xlsx"
