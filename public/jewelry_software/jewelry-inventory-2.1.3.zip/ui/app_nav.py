from nicegui import ui


def render_app_nav(active: str) -> None:
    with ui.row().classes("gap-4 items-center mb-2"):
        if active == "inventory":
            ui.label("Inventory").classes("font-semibold text-gray-900")
            ui.link("Flow", "/flow").classes("text-sm text-gray-600")
        elif active == "flow":
            ui.link("Inventory", "/").classes("text-sm text-gray-600")
            ui.label("Flow").classes("font-semibold text-gray-900")
        else:
            ui.link("Inventory", "/").classes("text-sm text-gray-600")
            ui.link("Flow", "/flow").classes("text-sm text-gray-600")
