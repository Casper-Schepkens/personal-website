from core.update_bootstrap import maybe_delegate_to_updater

maybe_delegate_to_updater()

from core.ensure_dependencies import ensure_dependencies

ensure_dependencies()

from nicegui import app, ui
from config.dev import ensure_dev_session, is_dev_mode
from config.settings import APP_DISPLAY_NAME, APP_HOST, APP_PORT, BRANDING_DIR, IMAGE_DIR, IMAGES_TO_ADD_DIR, THUMB_DIR
from core.local_data_service import ensure_local_data_layout
from core.license_middleware import license_middleware
from core.session_service import load_session
from ui.inventory_view import register_inventory_page
from ui.flow_view import register_flow_page
from ui.login_page import register_login_page, register_logout_handler
from ui.mobile_upload_page import register_mobile_upload_page

ensure_local_data_layout()

if is_dev_mode():
    dev_session = ensure_dev_session()
    print(
        f"DEV MODE: signed in as {dev_session.display_name} "
        f"({dev_session.account_type}) — local_data/jewelry.db"
    )

app.add_static_files("/thumbs", THUMB_DIR)
app.add_static_files("/photos", IMAGE_DIR)
app.add_static_files("/staging-photos", IMAGES_TO_ADD_DIR)
app.add_static_files("/shop-logo", BRANDING_DIR)

app.middleware("http")(license_middleware)

register_login_page()
register_logout_handler()
register_inventory_page()
register_flow_page()
register_mobile_upload_page()

session = load_session()
window_title = session.display_name if session else APP_DISPLAY_NAME

ui.run(
    title=window_title,
    host=APP_HOST,
    port=APP_PORT,
    storage_secret="jewelry-inventory-local-storage",
)
