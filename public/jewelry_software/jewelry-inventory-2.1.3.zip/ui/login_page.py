from nicegui import ui

from config.dev import ensure_dev_session, is_dev_mode, is_dev_workspace
from config.settings import APP_DISPLAY_NAME
from core.license_service import authenticate
from core.local_data_service import complete_sign_in, is_first_run, local_data_summary
from core.session_service import clear_session, load_session


def _home_path_for_session(session) -> str:
    return "/admin" if session.is_admin else "/"


def register_login_page() -> None:
    @ui.page("/login")
    def login_page() -> None:
        if is_dev_mode():
            session = ensure_dev_session()
            ui.navigate.to(_home_path_for_session(session))
            return

        existing = load_session()
        if existing is not None:
            ui.navigate.to(_home_path_for_session(existing))
            return

        first_run = is_first_run()

        ui.label(APP_DISPLAY_NAME).classes("text-2xl font-bold mt-8")
        if first_run:
            ui.label("Welcome — sign in to set up this computer").classes("text-gray-600 mb-2")
            ui.label(
                "Use the username and password from your administrator. "
                "Your inventory folder will be prepared automatically."
            ).classes("text-sm text-gray-500 mb-6 max-w-md")
        else:
            ui.label("Sign in to continue").classes("text-gray-600 mb-6")

        username = ui.input("Username").classes("w-full max-w-sm").props("outlined dense")
        password = ui.input("Password", password=True).classes("w-full max-w-sm").props(
            "outlined dense"
        )
        error = ui.label("").classes("text-red-600 text-sm min-h-[1.25rem]")

        def sign_in() -> None:
            error.text = ""
            result = authenticate(username.value or "", password.value or "")
            if result.session is None:
                error.text = result.error_message or "Sign in failed."
                return
            if result.session.is_admin and not is_dev_workspace():
                error.text = (
                    "Administrator accounts use the separate admin dashboard "
                    "(python ops/admin_main.py)."
                )
                return
            complete_sign_in(result.session)
            if first_run:
                ui.notify(
                    f"Setup complete — {local_data_summary()}.",
                    type="positive",
                )
            ui.navigate.to(_home_path_for_session(result.session))

        ui.button("Sign in", on_click=sign_in).props("no-caps color=primary").classes("mt-2")
        password.on("keydown.enter", sign_in)


def register_logout_handler() -> None:
    @ui.page("/logout")
    def logout_page() -> None:
        clear_session()
        ui.navigate.to("/login")
