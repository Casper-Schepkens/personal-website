import socket

from config.settings import APP_PORT


def get_lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.connect(("8.8.8.8", 80))
            return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def get_upload_url() -> str:
    return f"http://{get_lan_ip()}:{APP_PORT}/upload"
