from datetime import date, datetime

from nicegui import ui

from core.flow_service import days_to_sell, item_label, item_profit


def _format_euro(amount: float) -> str:
    return f"€ {int(round(amount)):,}"


def _format_item_date(value: str | None) -> str:
    if not value:
        return "—"
    try:
        return datetime.strptime(value[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
    except ValueError:
        return value[:10]


def _stat_row(label: str, value: str, *, value_classes: str = "") -> None:
    with ui.row().classes("w-full justify-between items-center py-1.5 border-b border-gray-100"):
        ui.label(label).classes("text-gray-600")
        ui.label(value).classes(f"font-medium {value_classes}".strip())


def render_sold_congrats(
    *,
    item: dict,
    sell_price: float,
    on_close,
) -> None:
    sold_date = date.today().isoformat()
    purchase_price = float(item["purchase_price"] or 0)
    sale_data = {
        "added_date": item["added_date"],
        "sold_date": sold_date,
        "purchase_price": purchase_price,
        "sell_price": sell_price,
    }
    profit = item_profit(sale_data)
    days = days_to_sell(sale_data)
    profit_class = "text-green-600" if profit >= 0 else "text-red-600"

    ui.label("Congratulations!").classes("text-2xl font-bold text-green-600 mb-1")
    ui.label(item_label(item)).classes("text-lg font-medium")
    ui.label(f"#{item['id']}").classes("text-sm text-gray-500 mb-4")

    _stat_row("Date bought", _format_item_date(item["added_date"]))
    _stat_row("Date sold", _format_item_date(sold_date))
    days_text = f"{days} days" if days is not None else "—"
    _stat_row("Days to sell", days_text)
    _stat_row("Purchase price", _format_euro(purchase_price))
    _stat_row("Sell price", _format_euro(sell_price))
    _stat_row("Profit", _format_euro(profit), value_classes=profit_class)

    ui.button("Close", on_click=on_close).classes(
        "w-full mt-6 bg-green-600 text-white"
    ).props("no-caps")


def open_sold_congrats_dialog(*, item: dict, sell_price: float) -> None:
    with ui.dialog() as dialog, ui.card().classes("p-6 w-full max-w-md"):
        render_sold_congrats(
            item=item,
            sell_price=sell_price,
            on_close=dialog.close,
        )

    dialog.open()
