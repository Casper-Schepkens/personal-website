import math

from nicegui import background_tasks, run, ui
from core.duplicate_service import find_duplicate_groups
from core.dismissed_duplicates import active_duplicate_group_count
from core.inventory_service import (
    CONSIGNMENT_FILTER_DEFAULT,
    FILTER_COLUMNS,
    FILTER_LABELS,
    load_filter_options,
    load_inventory,
    load_inventory_stats,
    load_price_bounds,
)
from core.image_service import create_thumbnail, get_thumbnail_url
from core.shop_branding_service import get_shop_logo_url, save_shop_logo
from config.settings import APP_VERSION, PAGE_SIZE
from core.network import get_upload_url
from core.session_service import load_session
from core.qr_utils import qr_data_url
from ui.app_nav import render_app_nav
from ui.dev_banner import render_dev_banner
from ui.doubles_dialog import open_doubles_dialog
from ui.item_add_dialog import open_item_add_dialog
from ui.item_edit_dialog import open_item_edit_dialog
from ui.photo_helpers import pick_shop_logo_from_folder

IMAGE_CLASSES = "w-[400px] h-[400px] object-cover shrink-0 bg-gray-100"
IMAGE_PROPS = "loading=lazy no-spinner no-transition"
PLACEHOLDER_SRC = (
    "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
)


def _format_euro(amount: float) -> str:
    return f"€ {int(round(amount)):,}"


def _format_weight(grams: float) -> str:
    if float(grams).is_integer():
        return f"{int(grams):,} g"
    return f"{grams:,.1f} g"


def _page_count(item_count: int) -> int:
    return max(1, math.ceil(item_count / PAGE_SIZE))


def _render_item_image(item_id: int) -> None:
    url = get_thumbnail_url(item_id)
    img = ui.image(url or PLACEHOLDER_SRC).props(IMAGE_PROPS).classes(IMAGE_CLASSES)

    if url:
        return

    async def generate_thumbnail() -> None:
        path = await run.cpu_bound(create_thumbnail, item_id)
        if not path or img.is_deleted:
            return
        thumb_url = get_thumbnail_url(item_id)
        if thumb_url:
            img.set_source(thumb_url)

    background_tasks.create(generate_thumbnail(), name=f"thumb-{item_id}")


def _render_item_card(item, on_saved) -> None:
    def open_edit() -> None:
        open_item_edit_dialog(item, on_saved=on_saved)

    with ui.card().classes("p-2 w-fit cursor-pointer hover:shadow-lg transition-shadow").on(
        "click", open_edit
    ):
        _render_item_image(item["id"])
        ui.label(f"{item['item_type']}").classes("font-bold text-lg")
        ui.label(f"{item['stone']} • {item['carat']} ct").classes("text-sm")
        ui.label(f"€ {item['sell_price']}").classes("text-green-600 font-semibold")
        ui.label(f"Stock: {item['stock']}").classes("text-xs text-gray-500")


def show_inventory():
    session = load_session()

    filter_values = {column: "All" for column in FILTER_COLUMNS}
    filter_values["consignment"] = CONSIGNMENT_FILTER_DEFAULT
    filter_options = load_filter_options(**filter_values)
    state = {"page": 1}
    inventory_cache: dict = {"key": None, "items": []}

    price_min_bound, price_max_bound = load_price_bounds()
    query_state = {
        "item_id": "",
        "price_min": price_min_bound,
        "price_max": price_max_bound,
    }

    def _filter_key() -> tuple:
        return (
            tuple(sorted(filter_values.items())),
            query_state["item_id"],
            query_state["price_min"],
            query_state["price_max"],
        )

    def _current_query_kwargs() -> dict:
        use_price_filter = (
            query_state["price_min"] > price_min_bound
            or query_state["price_max"] < price_max_bound
        )
        return {
            **filter_values,
            "item_id": query_state["item_id"],
            "price_min": query_state["price_min"] if use_price_filter else None,
            "price_max": query_state["price_max"] if use_price_filter else None,
        }

    def get_cached_items():
        key = _filter_key()
        if inventory_cache["key"] != key:
            inventory_cache["items"] = load_inventory(**_current_query_kwargs())
            inventory_cache["key"] = key
        return inventory_cache["items"]

    def invalidate_inventory_cache():
        inventory_cache["key"] = None

    def on_item_saved():
        invalidate_inventory_cache()
        refresh_filter_selects()
        stats_panel.refresh()
        problems_panel.refresh()
        inventory_grid.refresh()

    render_dev_banner()

    with ui.row().classes("w-full items-center justify-between mb-2 gap-4"):
        with ui.row().classes("items-center gap-4 grow min-w-0"):
            @ui.refreshable
            def shop_logo_panel():
                logo_url = get_shop_logo_url()
                with ui.column().classes("items-start gap-1 shrink-0"):
                    if logo_url:
                        ui.image(logo_url).classes(
                            "h-16 max-w-[240px] object-contain bg-white rounded"
                        )
                    ui.button(
                        "Change logo" if logo_url else "Add logo",
                        on_click=choose_shop_logo,
                    ).props("flat dense no-caps").classes("text-sm")

            def choose_shop_logo() -> None:
                path = pick_shop_logo_from_folder()
                if not path:
                    return
                try:
                    save_shop_logo(path)
                except OSError as exc:
                    ui.notify(f"Could not save logo: {exc}", type="negative")
                    return
                shop_logo_panel.refresh()
                ui.notify("Shop logo updated", type="positive")

            shop_logo_panel()

            shop_name = session.display_name if session else "Inventory"
            ui.label(shop_name).classes("text-2xl font-bold truncate")

        ui.link("Sign out", "/logout").classes("text-sm text-gray-500 shrink-0")

    render_app_nav("inventory")
    ui.label(f"Inventory · v{APP_VERSION}").classes("text-lg text-gray-600 mb-2")

    with ui.row().classes("w-full gap-6 items-start mb-4 flex-wrap"):
        # Filters ~65–70%; wrap onto next row on narrow widths
        with ui.column().classes("gap-3 min-w-0").style(
            "flex: 1 1 65%; max-width: 70%; min-width: min(100%, 28rem);"
        ):
            with ui.row().classes("gap-3 flex-wrap items-end w-full"):
                id_input = (
                    ui.input("ID", placeholder="#")
                    .classes("w-24 shrink-0")
                    .props("dense outlined clearable debounce=400")
                )

                selects = {}
                for column in FILTER_COLUMNS:
                    selects[column] = (
                        ui.select(
                            filter_options[column],
                            label=FILTER_LABELS[column],
                            value=filter_values[column],
                        )
                        .classes("min-w-[9.5rem] grow")
                        .style("flex: 1 1 9.5rem; max-width: 14rem;")
                        .props("dense outlined")
                    )

            with ui.column().classes("w-full gap-1"):
                price_label = ui.label("").classes("text-sm text-gray-600")
                price_range = (
                    ui.range(
                        min=price_min_bound,
                        max=price_max_bound,
                        value={"min": price_min_bound, "max": price_max_bound},
                        step=50,
                    )
                    .props("label color=primary")
                    .classes("w-full")
                )

                def update_price_label() -> None:
                    current = price_range.value or {
                        "min": price_min_bound,
                        "max": price_max_bound,
                    }
                    price_label.text = (
                        f"Sell price: {_format_euro(current['min'])} – "
                        f"{_format_euro(current['max'])}"
                    )

                update_price_label()

        with ui.column().classes("gap-2 text-sm items-end min-w-0").style(
            "flex: 1 1 28%; max-width: 32%; min-width: min(100%, 14rem);"
        ):
            ui.button(
                "Add new item",
                on_click=lambda: open_item_add_dialog(on_saved=on_item_saved),
            ).props("no-caps color=primary")

            export_btn = ui.button("Export to Excel").props("no-caps outline")

            async def export_inventory() -> None:
                if export_btn.is_deleted:
                    return
                export_btn.disable()
                export_btn.text = "Exporting..."
                try:
                    from core.export_service import (
                        build_inventory_excel,
                        inventory_export_filename,
                    )

                    shop_name = session.display_name if session else None
                    data = await run.cpu_bound(build_inventory_excel, shop_name=shop_name)
                    ui.download(data, inventory_export_filename())
                    ui.notify("Excel export downloaded", type="positive")
                except Exception as exc:
                    ui.notify(f"Export failed: {exc}", type="negative")
                finally:
                    if not export_btn.is_deleted:
                        export_btn.text = "Export to Excel"
                        export_btn.enable()

            export_btn.on("click", export_inventory)

            upload_url = get_upload_url()
            with ui.column().classes("gap-1 items-end mt-2"):
                ui.label("Phone upload").classes("font-semibold text-base")
                ui.image(qr_data_url(upload_url)).classes("w-28 h-28 bg-white p-1 rounded")
                ui.label("Scan to upload photos").classes("text-xs text-gray-500")
                ui.link(upload_url, upload_url, new_tab=True).classes(
                    "text-xs text-gray-400 break-all max-w-[14rem] text-right"
                )

            with ui.row().classes("gap-6 items-start mt-2 flex-wrap justify-end"):
                @ui.refreshable
                def stats_panel():
                    stats = load_inventory_stats(**_current_query_kwargs())
                    profit = stats["profit_total"]

                    with ui.column().classes("gap-1 items-end"):
                        ui.label("Overview").classes("font-semibold text-base")
                        ui.label(f"Items: {stats['item_count']}")
                        ui.label(f"In stock: {stats['in_stock_count']}")
                        ui.label(f"Buy total: {_format_euro(stats['buy_total'])}")
                        ui.label(f"Sell total: {_format_euro(stats['sell_total'])}")
                        ui.label(f"Profit: {_format_euro(profit)}").classes(
                            "text-green-600" if profit >= 0 else "text-red-600"
                        )
                        ui.label(f"Total weight: {_format_weight(stats['weight_total'])}")

                @ui.refreshable
                def problems_panel():
                    all_items = load_inventory()
                    group_count = active_duplicate_group_count(all_items)

                    with ui.column().classes("gap-1 items-end"):
                        ui.label("Possible problems").classes("font-semibold text-base")
                        doubles_label = (
                            f"Doubles ({group_count})"
                            if group_count
                            else "Doubles"
                        )
                        doubles_btn = ui.button(doubles_label).props("no-caps outline")

                        async def show_doubles() -> None:
                            if doubles_btn.is_deleted:
                                return
                            default_label = doubles_btn.text
                            doubles_btn.text = "Loading..."
                            doubles_btn.disable()
                            try:
                                items = load_inventory()
                                items_by_id = {item["id"]: item for item in items}
                                groups = await run.cpu_bound(find_duplicate_groups)
                                open_doubles_dialog(groups, items_by_id, on_item_saved)
                            finally:
                                if not doubles_btn.is_deleted:
                                    doubles_btn.text = default_label
                                    doubles_btn.enable()

                        doubles_btn.on("click", show_doubles)

                stats_panel()
                problems_panel()

    range_label = ui.label("").classes("text-sm text-gray-600 mb-2")
    grid_area = ui.column().classes("w-full")

    with ui.row().classes("w-full justify-center mt-4"):
        pagination = ui.pagination(1, 1, direction_links=True)

    @ui.refreshable
    def inventory_grid():
        items = get_cached_items()
        total = len(items)
        pages = _page_count(total)

        if state["page"] > pages:
            state["page"] = pages
            pagination.value = pages

        pagination.max = pages

        if total == 0:
            range_label.text = "No items match these filters."
            ui.label("No items match these filters.").classes("text-gray-500")
            return

        start = (state["page"] - 1) * PAGE_SIZE
        end = min(start + PAGE_SIZE, total)
        range_label.text = f"Showing {start + 1}–{end} of {total}"

        with ui.grid(columns=4).classes("w-full gap-4"):
            for item in items[start:end]:
                _render_item_card(item, on_item_saved)

    def on_page_change(e):
        state["page"] = e.value
        inventory_grid.refresh()

    pagination.on_value_change(on_page_change)

    updating_selects = False

    def refresh_filter_selects():
        nonlocal updating_selects
        updating_selects = True
        try:
            options = load_filter_options(**_current_query_kwargs())
            for column, select in selects.items():
                current = filter_values[column]
                values = set(options[column].keys())
                if current not in values:
                    current = (
                        CONSIGNMENT_FILTER_DEFAULT
                        if column == "consignment"
                        else "All"
                    )
                    filter_values[column] = current
                select.set_options(options[column], value=current)
        finally:
            updating_selects = False

    def apply_filters():
        if updating_selects:
            return
        for column, select in selects.items():
            filter_values[column] = select.value or "All"
        query_state["item_id"] = (id_input.value or "").strip()
        current_range = price_range.value or {
            "min": price_min_bound,
            "max": price_max_bound,
        }
        query_state["price_min"] = float(current_range["min"])
        query_state["price_max"] = float(current_range["max"])
        update_price_label()
        state["page"] = 1
        pagination.value = 1
        invalidate_inventory_cache()
        refresh_filter_selects()
        stats_panel.refresh()
        inventory_grid.refresh()

    for select in selects.values():
        select.on("update:model-value", apply_filters)

    id_input.on("update:model-value", apply_filters)
    id_input.on("keydown.enter", apply_filters)
    price_range.on("update:model-value", apply_filters)

    with grid_area:
        inventory_grid()


def register_inventory_page() -> None:
    @ui.page("/")
    def inventory_page() -> None:
        from config.dev import is_dev_mode

        if load_session() is None and not is_dev_mode():
            ui.navigate.to("/login")
            return
        show_inventory()
