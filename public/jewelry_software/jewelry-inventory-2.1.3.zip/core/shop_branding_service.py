"""Per-shop branding stored in local_data."""

from __future__ import annotations

import os

from PIL import Image

from config.settings import SHOP_LOGO_FILENAME, SHOP_LOGO_PATH, SHOP_LOGO_URL_PREFIX

MAX_LOGO_HEIGHT = 120
MAX_LOGO_WIDTH = 320


def has_shop_logo() -> bool:
    return os.path.isfile(SHOP_LOGO_PATH)


def get_shop_logo_url() -> str | None:
    if not has_shop_logo():
        return None
    version = int(os.path.getmtime(SHOP_LOGO_PATH))
    return f"{SHOP_LOGO_URL_PREFIX}/{SHOP_LOGO_FILENAME}?v={version}"


def save_shop_logo(source_path: str) -> None:
    if not os.path.isfile(source_path):
        raise FileNotFoundError(f"Logo not found: {source_path}")

    os.makedirs(os.path.dirname(SHOP_LOGO_PATH), exist_ok=True)

    image = Image.open(source_path)
    if image.mode not in ("RGB", "RGBA"):
        image = image.convert("RGBA")
    elif image.mode == "RGB":
        image = image.convert("RGBA")

    width, height = image.size
    scale = min(MAX_LOGO_WIDTH / width, MAX_LOGO_HEIGHT / height, 1.0)
    if scale < 1.0:
        new_size = (max(1, int(width * scale)), max(1, int(height * scale)))
        image = image.resize(new_size, Image.Resampling.LANCZOS)

    image.save(SHOP_LOGO_PATH, optimize=True)
