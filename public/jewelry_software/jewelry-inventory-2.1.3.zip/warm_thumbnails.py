"""Pre-generate all missing thumbnails. Run once: python warm_thumbnails.py"""
from data.db import get_connection
from core.image_service import create_missing_thumbnails


def main():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM items ORDER BY id")
    item_ids = [row[0] for row in cursor.fetchall()]
    conn.close()

    created = create_missing_thumbnails(item_ids)
    print(f"Done. Generated {created} new thumbnail(s) for {len(item_ids)} item(s).")


if __name__ == "__main__":
    main()
