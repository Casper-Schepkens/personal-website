from collections.abc import Callable

from nicegui import background_tasks, run, ui

from core.dismissed_duplicates import (
    dismiss_group,
    restore_group,
    split_duplicate_groups,
)
from core.duplicate_service import DuplicateGroup
from core.image_service import create_thumbnail, get_thumbnail_url
from ui.item_edit_dialog import open_item_edit_dialog
from ui.photo_display import PLACEHOLDER_SRC, bind_photo_on_dialog_show

REASON_LABELS = {
    "image": "Same photo",
    "details": "Same details",
}


def _item_summary(item) -> str:
    stone = item["stone"] or ""
    item_type = item["item_type"] or ""
    carat = item["carat"] or 0
    return f"#{item['id']} · {item_type} · {stone} · {carat:.2f} ct"


def open_doubles_dialog(
    groups: list[DuplicateGroup],
    items_by_id: dict[int, object],
    on_saved: Callable[[], None] | None = None,
) -> None:
    with ui.dialog() as dialog, ui.card().classes("p-6 w-full max-w-3xl"):
        ui.label("Possible doubles").classes("text-xl font-bold mb-2")

        if not groups:
            ui.label("No duplicate items found.").classes("text-gray-600 mb-4")
            ui.button("Close", on_click=dialog.close).props("no-caps flat")
            dialog.open()
            return

        active_groups, dismissed_groups = split_duplicate_groups(groups)
        state = {
            "active": list(active_groups),
            "dismissed": list(dismissed_groups),
        }

        @ui.refreshable
        def body() -> None:
            with ui.tabs().classes("w-full") as tabs:
                active_tab = ui.tab(
                    f"Open ({len(state['active'])})"
                )
                dismissed_tab = ui.tab(
                    f"Acknowledged ({len(state['dismissed'])})"
                )

            with ui.tab_panels(tabs, value=active_tab).classes("w-full"):
                with ui.tab_panel(active_tab):
                    if not state["active"]:
                        ui.label("No open duplicate groups.").classes(
                            "text-gray-600 py-4"
                        )
                    else:
                        with ui.column().classes(
                            "w-full gap-4 max-h-[60vh] overflow-y-auto"
                        ):
                            for index, group in enumerate(state["active"], start=1):
                                _render_duplicate_group(
                                    index,
                                    group,
                                    items_by_id,
                                    dialog,
                                    on_saved,
                                    mode="active",
                                    on_change=refresh_lists,
                                )

                with ui.tab_panel(dismissed_tab):
                    if not state["dismissed"]:
                        ui.label("Nothing acknowledged yet.").classes(
                            "text-gray-600 py-4"
                        )
                    else:
                        with ui.column().classes(
                            "w-full gap-4 max-h-[60vh] overflow-y-auto"
                        ):
                            for index, group in enumerate(state["dismissed"], start=1):
                                _render_duplicate_group(
                                    index,
                                    group,
                                    items_by_id,
                                    dialog,
                                    on_saved,
                                    mode="dismissed",
                                    on_change=refresh_lists,
                                )

        def refresh_lists() -> None:
            active, dismissed = split_duplicate_groups(groups)
            state["active"] = list(active)
            state["dismissed"] = list(dismissed)
            body.refresh()
            if on_saved:
                on_saved()

        body()
        ui.button("Close", on_click=dialog.close).classes("w-full mt-4").props(
            "no-caps flat"
        )

    dialog.open()


def _render_duplicate_group(
    index: int,
    group: DuplicateGroup,
    items_by_id: dict[int, object],
    dialog: ui.dialog,
    on_saved: Callable[[], None] | None,
    *,
    mode: str,
    on_change: Callable[[], None],
) -> None:
    reason = REASON_LABELS.get(group.reason, group.reason)

    with ui.card().classes("w-full p-4"):
        with ui.row().classes("w-full items-start justify-between gap-3 mb-3"):
            ui.label(f"Group {index}: {reason}").classes("font-semibold")
            if mode == "active":

                def acknowledge() -> None:
                    dismiss_group(group)
                    ui.notify("Acknowledged — moved to the other tab", type="positive")
                    on_change()

                ui.button("Acknowledge", on_click=acknowledge).props(
                    "flat dense no-caps"
                ).props("icon=check color=primary")
            else:

                def restore() -> None:
                    restore_group(group)
                    ui.notify("Restored to open list", type="positive")
                    on_change()

                ui.button("Restore", on_click=restore).props(
                    "flat dense no-caps"
                ).props("icon=undo")

        with ui.row().classes("w-full gap-4 flex-wrap"):
            for item_id in group.item_ids:
                item = items_by_id.get(item_id)
                if not item:
                    continue
                _render_duplicate_item(item, dialog, on_saved)


def _render_duplicate_item(
    item,
    dialog: ui.dialog,
    on_saved: Callable[[], None] | None,
) -> None:
    item_id = item["id"]
    thumb_url = get_thumbnail_url(item_id)

    def open_edit() -> None:
        open_item_edit_dialog(item, on_saved=on_saved)

    with ui.card().classes(
        "p-2 w-48 cursor-pointer hover:shadow-lg transition-shadow"
    ).on("click", open_edit):
        img = (
            ui.image(PLACEHOLDER_SRC)
            .classes("w-full h-32 object-cover bg-gray-100 rounded")
            .props("fit=cover")
        )

        if thumb_url:
            bind_photo_on_dialog_show(img, thumb_url, dialog)
        else:

            async def generate_thumbnail() -> None:
                path = await run.cpu_bound(create_thumbnail, item_id)
                if not path or img.is_deleted:
                    return
                url = get_thumbnail_url(item_id)
                if url:
                    img.set_source(url)

            background_tasks.create(
                generate_thumbnail(), name=f"doubles-thumb-{item_id}"
            )

        ui.label(_item_summary(item)).classes("text-sm mt-2")
        ui.label(f"Stock: {item['stock']}").classes("text-xs text-gray-500")
