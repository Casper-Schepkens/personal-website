from __future__ import annotations

from calendar import monthrange
from datetime import date, datetime, timedelta

from data.inventory_repo import get_items_by_date_column, get_longest_in_stock_items

PERIOD_MODES = ("7days", "month", "year", "custom")


def item_label(item) -> str:
    stone = (item["stone"] or "").strip().lower()
    item_type = item["item_type"] or ""
    if stone == "none":
        return f"{item['metal']} {item_type}".strip()
    return f"{item['stone']} {item_type}".strip()


def item_profit(item) -> float:
    purchase = float(item["purchase_price"] or 0)
    sell = float(item["sell_price"] or 0)
    return sell - purchase


def margin_pct(profit: float, revenue: float) -> float | None:
    if revenue <= 0:
        return None
    return (profit / revenue) * 100


def item_margin_pct(item) -> float | None:
    sell = float(item["sell_price"] or 0)
    return margin_pct(item_profit(item), sell)


def parse_month_value(value) -> tuple[int, int] | None:
    if value is None or str(value).strip() == "":
        return None
    try:
        parsed = datetime.strptime(str(value)[:7], "%Y-%m")
        return parsed.year, parsed.month
    except ValueError:
        return None


def month_bounds(year: int, month: int) -> tuple[date, date]:
    last_day = monthrange(year, month)[1]
    start = date(year, month, 1)
    return start, date(year, month, last_day)


def year_bounds(year: int) -> tuple[date, date]:
    return date(year, 1, 1), date(year, 12, 31)


def _parse_item_date(value) -> date | None:
    if value is None or str(value).strip() == "":
        return None
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def days_in_stock(item, *, reference: date | None = None) -> int | None:
    added = _parse_item_date(item["added_date"])
    if added is None:
        return None
    today = reference or date.today()
    return max((today - added).days, 0)


def days_to_sell(item) -> int | None:
    added = _parse_item_date(item["added_date"])
    sold = _parse_item_date(item["sold_date"])
    if added is None or sold is None:
        return None
    return max((sold - added).days, 0)


def average_days_to_sell(sold_items) -> float | None:
    values = [days for item in sold_items if (days := days_to_sell(item)) is not None]
    if not values:
        return None
    return sum(values) / len(values)


def chart_granularity(start: date, end: date) -> str:
    days = (end - start).days + 1
    if days <= 14:
        return "day"
    if days <= 90:
        return "week"
    return "month"


def _bucket_key(value: date, granularity: str) -> str:
    if granularity == "day":
        return value.isoformat()
    if granularity == "week":
        week_start = value - timedelta(days=value.weekday())
        return week_start.isoformat()
    return f"{value.year}-{value.month:02d}"


def _bucket_keys(start: date, end: date, granularity: str) -> list[str]:
    if granularity == "day":
        keys: list[str] = []
        current = start
        while current <= end:
            keys.append(current.isoformat())
            current += timedelta(days=1)
        return keys

    if granularity == "week":
        keys = []
        current = start - timedelta(days=start.weekday())
        while current <= end:
            keys.append(current.isoformat())
            current += timedelta(days=7)
        return keys

    keys = []
    year, month = start.year, start.month
    while (year, month) <= (end.year, end.month):
        keys.append(f"{year}-{month:02d}")
        month += 1
        if month > 12:
            month = 1
            year += 1
    return keys


def _bucket_label(key: str, granularity: str) -> str:
    if granularity == "month":
        year, month = key.split("-")
        return datetime(int(year), int(month), 1).strftime("%b %Y")

    parsed = datetime.strptime(key[:10], "%Y-%m-%d").date()
    if granularity == "week":
        return parsed.strftime("%d/%m")
    return parsed.strftime("%d/%m")


def build_flow_chart_data(
    added_items,
    sold_items,
    *,
    period_start: date,
    period_end: date,
) -> dict:
    granularity = chart_granularity(period_start, period_end)
    keys = _bucket_keys(period_start, period_end, granularity)
    counts = {key: {"added": 0, "sold": 0, "profit": 0.0} for key in keys}

    for item in added_items:
        item_date = _parse_item_date(item["added_date"])
        if item_date is None:
            continue
        key = _bucket_key(item_date, granularity)
        if key in counts:
            counts[key]["added"] += 1

    for item in sold_items:
        item_date = _parse_item_date(item["sold_date"])
        if item_date is None:
            continue
        key = _bucket_key(item_date, granularity)
        if key in counts:
            counts[key]["sold"] += 1
            counts[key]["profit"] += item_profit(item)

    labels = [_bucket_label(key, granularity) for key in keys]
    return {
        "granularity": granularity,
        "labels": labels,
        "added_counts": [counts[key]["added"] for key in keys],
        "sold_counts": [counts[key]["sold"] for key in keys],
        "profit_totals": [counts[key]["profit"] for key in keys],
    }


def build_type_breakdown(sold_items) -> dict[str, dict[str, float]]:
    revenue: dict[str, float] = {}
    profit: dict[str, float] = {}
    for item in sold_items:
        item_type = item["item_type"] or "Unknown"
        revenue[item_type] = revenue.get(item_type, 0.0) + float(item["sell_price"] or 0)
        profit[item_type] = profit.get(item_type, 0.0) + item_profit(item)

    margin_by_type: dict[str, float] = {}
    for item_type, type_revenue in revenue.items():
        type_profit = profit.get(item_type, 0.0)
        pct = margin_pct(type_profit, type_revenue)
        if pct is not None:
            margin_by_type[item_type] = pct

    return {"revenue": revenue, "profit": profit, "margin_pct": margin_by_type}


def build_daily_profit_charts(
    sold_items,
    *,
    period_start: date,
    period_end: date,
) -> dict:
    keys = _bucket_keys(period_start, period_end, "day")
    daily = {key: 0.0 for key in keys}

    for item in sold_items:
        item_date = _parse_item_date(item["sold_date"])
        if item_date is None:
            continue
        key = item_date.isoformat()
        if key in daily:
            daily[key] += item_profit(item)

    daily_values = [daily[key] for key in keys]
    cumulative_values: list[float] = []
    running = 0.0
    for value in daily_values:
        running += value
        cumulative_values.append(running)

    labels = [_bucket_label(key, "day") for key in keys]
    return {
        "labels": labels,
        "daily_profit": daily_values,
        "cumulative_profit": cumulative_values,
    }


def format_net_items(added_count: int, sold_count: int) -> str:
    net = added_count - sold_count
    sign = "+" if net > 0 else ""
    return f"{sign}{net}"


def period_bounds(
    mode: str,
    *,
    custom_start: date | None = None,
    custom_end: date | None = None,
    selected_month: str | None = None,
    selected_year: int | None = None,
    reference: date | None = None,
) -> tuple[date, date]:
    today = reference or date.today()

    if mode == "7days":
        return today - timedelta(days=6), today

    if mode == "month":
        parsed = parse_month_value(selected_month)
        if parsed is None:
            parsed = (today.year, today.month)
        return month_bounds(parsed[0], parsed[1])

    if mode == "year":
        year = selected_year or today.year
        return year_bounds(year)

    if mode == "custom":
        if custom_start is None or custom_end is None:
            raise ValueError("Custom period requires start and end dates")
        if custom_start > custom_end:
            return custom_end, custom_start
        return custom_start, custom_end

    raise ValueError(f"Invalid period mode: {mode}")


def previous_period_bounds(
    mode: str,
    period_start: date,
    period_end: date,
) -> tuple[date, date]:
    if mode == "7days":
        previous_end = period_start - timedelta(days=1)
        previous_start = previous_end - timedelta(days=6)
        return previous_start, previous_end

    if mode == "month":
        previous_end = period_start.replace(day=1) - timedelta(days=1)
        previous_start = previous_end.replace(day=1)
        return previous_start, previous_end

    if mode == "year":
        previous_year = period_start.year - 1
        return (
            date(previous_year, 1, 1),
            date(previous_year, 12, 31),
        )

    if mode == "custom":
        length_days = (period_end - period_start).days + 1
        previous_end = period_start - timedelta(days=1)
        previous_start = previous_end - timedelta(days=length_days - 1)
        return previous_start, previous_end

    raise ValueError(f"Invalid period mode: {mode}")


def build_added_outcomes(added_items) -> dict:
    sold = 0
    in_stock = 0
    reserved = 0
    for item in added_items:
        stock = (item["stock"] or "").strip().lower()
        if stock == "sold":
            sold += 1
        elif stock == "reserved":
            reserved += 1
        else:
            in_stock += 1
    return {
        "sold": sold,
        "in_stock": in_stock,
        "reserved": reserved,
        "total": len(added_items),
    }


def build_cash_view(added_items, sold_items) -> dict:
    cash_out = sum(float(item["purchase_price"] or 0) for item in added_items)
    cash_in = sum(float(item["sell_price"] or 0) for item in sold_items)
    return {
        "cash_out": cash_out,
        "cash_in": cash_in,
        "net_cash": cash_in - cash_out,
    }


def _build_summary(added_items, sold_items) -> dict:
    added_purchase_total = sum(float(item["purchase_price"] or 0) for item in added_items)
    added_sell_total = sum(float(item["sell_price"] or 0) for item in added_items)
    sold_purchase_total = sum(float(item["purchase_price"] or 0) for item in sold_items)
    sold_sell_total = sum(float(item["sell_price"] or 0) for item in sold_items)
    added_count = len(added_items)
    sold_count = len(sold_items)
    sold_profit_total = sold_sell_total - sold_purchase_total

    return {
        "added_count": added_count,
        "added_purchase_total": added_purchase_total,
        "added_sell_total": added_sell_total,
        "sold_count": sold_count,
        "sold_purchase_total": sold_purchase_total,
        "sold_sell_total": sold_sell_total,
        "sold_profit_total": sold_profit_total,
        "sold_margin_pct": margin_pct(sold_profit_total, sold_sell_total),
        "net_items": added_count - sold_count,
        "net_cash": sold_sell_total - added_purchase_total,
        "average_days_to_sell": average_days_to_sell(sold_items),
        "added_outcomes": build_added_outcomes(added_items),
        "cash": build_cash_view(added_items, sold_items),
    }


def _build_comparison(current: dict, previous: dict) -> dict:
    def metric(key: str) -> dict:
        current_value = current[key]
        previous_value = previous[key]
        if current_value is None or previous_value is None:
            return {
                "current": current_value,
                "previous": previous_value,
                "diff": None,
                "percent": None,
            }
        diff = current_value - previous_value
        percent = (diff / previous_value) * 100 if previous_value else None
        return {
            "current": current_value,
            "previous": previous_value,
            "diff": diff,
            "percent": percent,
        }

    return {
        "added_count": metric("added_count"),
        "added_purchase": metric("added_purchase_total"),
        "sold_count": metric("sold_count"),
        "sold_revenue": metric("sold_sell_total"),
        "sold_profit": metric("sold_profit_total"),
        "sold_margin_pct": metric("sold_margin_pct"),
        "net_cash": metric("net_cash"),
    }


def load_flow_data_for_range(
    start: date,
    end: date,
    *,
    item_type: str = "All",
) -> dict:
    start_iso = start.isoformat()
    end_iso = end.isoformat()

    added_items = get_items_by_date_column(
        "added_date",
        start_iso,
        end_iso,
        item_type=item_type,
    )
    sold_items = get_items_by_date_column(
        "sold_date",
        start_iso,
        end_iso,
        item_type=item_type,
    )
    summary = _build_summary(added_items, sold_items)

    return {
        "period_start": start,
        "period_end": end,
        "added_items": added_items,
        "sold_items": sold_items,
        "chart": build_flow_chart_data(
            added_items,
            sold_items,
            period_start=start,
            period_end=end,
        ),
        "profit_charts": build_daily_profit_charts(
            sold_items,
            period_start=start,
            period_end=end,
        ),
        "type_breakdown": build_type_breakdown(sold_items),
        "summary": summary,
    }


def load_flow_data(
    mode: str,
    *,
    item_type: str = "All",
    custom_start: date | None = None,
    custom_end: date | None = None,
    selected_month: str | None = None,
    selected_year: int | None = None,
) -> dict:
    start, end = period_bounds(
        mode,
        custom_start=custom_start,
        custom_end=custom_end,
        selected_month=selected_month,
        selected_year=selected_year,
    )
    current = load_flow_data_for_range(start, end, item_type=item_type)

    previous_start, previous_end = previous_period_bounds(mode, start, end)
    previous = load_flow_data_for_range(
        previous_start,
        previous_end,
        item_type=item_type,
    )

    current["previous_period_start"] = previous_start
    current["previous_period_end"] = previous_end
    current["comparison"] = _build_comparison(current["summary"], previous["summary"])
    return current


def load_longest_in_stock(*, item_type: str = "All", limit: int = 25) -> list[dict]:
    items = get_longest_in_stock_items(item_type=item_type, limit=limit)
    rows: list[dict] = []
    for item in items:
        days = days_in_stock(item)
        if days is None:
            continue
        rows.append(
            {
                "id": item["id"],
                "label": item_label(item),
                "item_type": item["item_type"],
                "stock": item["stock"],
                "added_date": item["added_date"],
                "days_in_stock": days,
                "sell_price": float(item["sell_price"] or 0),
            }
        )
    return rows
