from nicegui import events, ui

from config.settings import APP_DISPLAY_NAME
from core.network import get_upload_url
from core.phone_upload_service import save_phone_upload


def register_mobile_upload_page() -> None:
    @ui.page("/upload")
    def phone_upload_page() -> None:
        upload_url = get_upload_url()
        state = {"count": 0}

        ui.label(APP_DISPLAY_NAME).classes("text-2xl font-bold mt-4")
        ui.label("Upload photos from your phone").classes("text-gray-600 mb-6")

        status = ui.label("Select one or more photos to upload.").classes(
            "text-sm text-gray-600 mb-4"
        )

        async def handle_upload(event: events.UploadEventArguments) -> None:
            content = await event.file.read()
            save_phone_upload(content, event.file.name)
            state["count"] += 1
            status.text = f"{state['count']} photo(s) uploaded — ready to process on the PC."
            ui.notify(f"Uploaded {event.file.name}", type="positive")

        upload_props = "multiple auto-upload"

        with ui.column().classes("w-full max-w-md gap-3"):
            ui.upload(
                label="Choose from gallery",
                multiple=True,
                auto_upload=True,
                on_upload=handle_upload,
            ).props(f'{upload_props} accept="image/*"').classes("w-full")

            ui.upload(
                label="Take photo",
                multiple=True,
                auto_upload=True,
                on_upload=handle_upload,
            ).props(f'{upload_props} accept="image/*" capture="environment"').classes(
                "w-full"
            )

        ui.label(
            "Photos are stored temporarily and converted to PNG when "
            '"Add new item" is opened on the main computer.'
        ).classes("text-xs text-gray-500 mt-6 max-w-md")

        ui.link("Back to inventory", "/").classes("mt-4 text-sm")

        ui.label(upload_url).classes("text-xs text-gray-400 mt-8 break-all max-w-md")
